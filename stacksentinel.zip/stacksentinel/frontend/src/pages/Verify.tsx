import { useState } from "react";
import { J, get, send, upload, useAsync } from "../services/api";
import { Btn, Card, Decision, DemoTag, Empty, Err, Mono, PageHead, SevBadge } from "../components/ui";
import { useApp } from "../components/Shell";

const ST: Record<string, string> = { proposed: "text-amber", verified: "text-lime", not_resolved: "text-crit" };

export default function Verify() {
  const { scanId, scan, scans, refresh, openFinding, setScanId } = useApp();
  const rem = useAsync(() => (scanId ? get(`/remediations?scan_id=${scanId}`) : Promise.resolve([])), [scanId]);
  const [after, setAfter] = useState<number | "">("");
  const [res, setRes] = useState<J | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const run = async () => { setBusy(true); setErr(null); try { setRes(await send("/compare", "POST", { before_scan_id: scanId, after_scan_id: after })); rem.reload(); refresh(); } catch (e: any) { setErr(e.message); } setBusy(false); };
  const importNew = async (file: File | undefined) => { if (!file) return; setErr(null); const f = new FormData(); f.append("file", file); try { const r = await upload("/scans/trivy-report", f); refresh(); setAfter(r.scan.id); } catch (e: any) { setErr(e.message); } };
  const col = (title: string, items: J[], color: string) => (
    <div className="border border-line"><div className="border-b border-line px-3 py-2 font-display text-[16px]" style={{ color }}>{title} ({items.length})</div>
      <ul className="max-h-72 overflow-auto p-2 text-[12px]">{items.length === 0 && <li className="p-1 text-mute">None</li>}{items.map((f) => <li key={f.key}><button onClick={() => openFinding(f.id)} className="flex w-full items-center justify-between gap-2 p-1 text-left hover:bg-panel"><Mono>{f.ref_id} {f.pkg ?? ""}</Mono><SevBadge s={f.severity} /></button></li>)}</ul></div>);
  const candidates = scans.filter((s) => s.id !== scanId);
  return (<>
    <PageHead title="Fix to verify" sub="Findings are resolved only when a later scan no longer contains them. Recording a fix never marks anything resolved." right={scan?.is_demo ? <DemoTag /> : undefined} />
    <Err msg={err} />
    <div className="grid gap-5 md:grid-cols-2">
      <Card title={`1. Recorded remediations for #${scanId} (${scan?.image_ref ?? ""})`}>
        {rem.data?.length ? <ul className="space-y-2 text-[13px]">{rem.data.map((r: any) => <li key={r.id}><button onClick={() => openFinding(r.finding_id)} className="font-mono text-lime hover:underline">finding #{r.finding_id}</button> <Mono className={ST[r.status]}>[{r.status}]</Mono><div className="text-mute">{r.proposed_change}</div></li>)}</ul>
          : <Empty>None yet. Open a finding in Findings and record the change you plan to make.</Empty>}</Card>
      <Card title="2. Choose the updated scan">
        <div className="space-y-3 text-[13px]"><label className="block text-mute">Compare against<select value={after} onChange={(e) => setAfter(e.target.value === "" ? "" : Number(e.target.value))} className="mt-1 block w-full border border-line bg-ink p-1.5 text-ivory">
          <option value="">Select a scan...</option>{candidates.map((s) => <option key={s.id} value={s.id}>#{s.id} {s.image_ref}{s.is_demo ? " [DEMO]" : ""}</option>)}</select></label>
          <label className="block text-mute">or import a new Trivy report<input type="file" accept=".json" onChange={(e) => importNew(e.target.files?.[0])} className="mt-1 block text-[12px]" /></label>
          <Btn kind="primary" onClick={run} disabled={!after || busy}>3. Compare and re-evaluate policy</Btn></div></Card>
    </div>
    {res && (<div className="mt-5 space-y-5">
      {res.warning && <div className="border border-amber/60 bg-amber/10 px-3 py-2 text-[13px] text-amber">{res.warning}</div>}
      <Card title="Before and after"><div className="grid gap-4 text-center md:grid-cols-[1fr_auto_1fr]">
        {[["Before", res.before, res.before_risk, res.before_decision], null, ["After", res.after, res.after_risk, res.after_decision]].map((x: any, i) => x === null ? <div key={i} className="self-center font-display text-[28px] text-lime">&rarr;</div> : (
          <div key={x[0]} className="border border-line p-3"><div className="text-[12px] text-mute">{x[0]}</div><Mono>{x[1].image_ref}</Mono><div className="my-1 font-display text-[36px]">{x[2].score}</div><div className="text-[12px] text-mute">{x[2].classification} risk</div><div className="mt-2"><Decision d={x[3].outcome} /></div></div>))}</div>
        <p className="mt-3 text-[13px] text-mute">Risk moved by <Mono className={res.after_risk.score <= res.before_risk.score ? "text-lime" : "text-crit"}>{(res.after_risk.score - res.before_risk.score).toFixed(1)}</Mono> points. The policy was re-evaluated on the updated scan using the active policy.</p></Card>
      <div className="grid gap-4 md:grid-cols-3">{col("Resolved", res.comparison.resolved, "#b8f03c")}{col("Remaining", res.comparison.remaining, "#f0a83a")}{col("Newly introduced", res.comparison.introduced, "#e5484d")}</div>
      <Btn onClick={() => { setScanId(Number(after)); }}>Make the updated scan active</Btn>
    </div>)}
  </>);
}
