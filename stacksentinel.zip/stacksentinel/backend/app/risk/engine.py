"""Deterministic, explainable risk model (rule-based baseline). No ML is claimed or used."""
import math

MODEL_VERSION = "rules-1.0"
SEV_BASE = {"CRITICAL": 40.0, "HIGH": 20.0, "MEDIUM": 8.0, "LOW": 2.0, "UNKNOWN": 1.0}
POLICY_PRESSURE_PER_VIOLATION, POLICY_PRESSURE_CAP = 5.0, 15.0
SCALE = 100.0


def finding_points(f: dict) -> tuple[float, list[str]]:
    base = SEV_BASE.get(f["severity"], 1.0)
    mult, notes = 1.0, [f"scanner severity {f['severity']} -> base {base:g}"]
    if f.get("cvss") is not None:
        mult *= 0.8 + 0.04 * f["cvss"]
        notes.append(f"scanner CVSS {f['cvss']:g} ({f.get('cvss_source')}) -> x{0.8 + 0.04 * f['cvss']:.2f}")
    elif f["kind"] == "vulnerability":
        notes.append("no CVSS provided -> x1.00")
    if f.get("exploit_known") is True:
        mult *= 1.5
        notes.append("exploitation evidence supplied -> x1.50")
    return round(base * mult, 2), notes


def classify(score: float, has_critical: bool) -> str:
    cls = "Clean" if score == 0 else "Low" if score < 25 else "Medium" if score < 50 else "High" if score < 75 else "Critical"
    if has_critical and cls in ("Clean", "Low", "Medium"):
        cls = "High"  # floor: a critical finding is never rated below High
    return cls


def compute_risk(findings: list[dict], policy_violations: int = 0) -> dict:
    """findings: dicts with id, kind, severity, cvss, cvss_source, exploit_known, ref_id, pkg."""
    factors: dict[str, dict] = {}
    scored = []
    for f in findings:
        pts, notes = finding_points(f)
        scored.append((pts, f, notes))
        cat = f"{'Config' if f['kind'] == 'config' else 'Vulnerability'} - {f['severity']}"
        fac = factors.setdefault(cat, {"factor": cat, "count": 0, "points": 0.0, "finding_ids": []})
        fac["count"] += 1
        fac["points"] = round(fac["points"] + pts, 2)
        fac["finding_ids"].append(f["id"])
    pressure = min(policy_violations * POLICY_PRESSURE_PER_VIOLATION, POLICY_PRESSURE_CAP)
    if pressure:
        factors["Policy pressure"] = {"factor": "Policy pressure", "count": policy_violations, "points": pressure, "finding_ids": []}
    total = round(sum(x["points"] for x in factors.values()), 2)
    score = round(100 * (1 - math.exp(-total / SCALE)), 1)
    has_crit = any(f["severity"] == "CRITICAL" for f in findings)
    cls = classify(score, has_crit)
    for fac in factors.values():
        fac["share_pct"] = round(100 * fac["points"] / total, 1) if total else 0.0
        fac["finding_ids"] = fac["finding_ids"][:50]
    top = sorted(scored, key=lambda t: (-t[0], t[1]["id"]))[:5]
    n_vuln = [f for f in findings if f["kind"] == "vulnerability"]
    missing = []
    if n_vuln:
        nc = sum(1 for f in n_vuln if f.get("cvss") is None)
        if nc:
            missing.append(f"CVSS not provided by scanner for {nc} of {len(n_vuln)} vulnerabilities.")
        ne = sum(1 for f in n_vuln if f.get("exploit_known") is None)
        if ne:
            missing.append(f"Exploit evidence (KEV/EPSS) not provided for {ne} vulnerabilities; none was assumed.")
    missing.append("Runtime exposure (internet-facing, network policy) is unknown and not scored.")
    why = (f"Score {score}/100 ({cls}) from {total:g} weighted points across {len(findings)} findings."
           + (" A critical finding sets a floor of 'High'." if has_crit and cls == "High" and score < 50 else ""))
    return {
        "model": MODEL_VERSION, "score": score, "classification": cls, "total_points": total,
        "formula": "score = 100 * (1 - exp(-points/100)); points = severity base x CVSS factor x exploit factor",
        "factors": sorted(factors.values(), key=lambda x: -x["points"]),
        "top_contributors": [{"finding_id": f["id"], "ref_id": f["ref_id"], "pkg": f.get("pkg"), "points": p, "reasoning": n} for p, f, n in top],
        "missing_information": missing, "explanation": why,
    }
