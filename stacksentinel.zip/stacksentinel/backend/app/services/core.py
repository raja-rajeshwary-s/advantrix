from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models.models import Decision, Finding, Policy, Scan
from ..policies.engine import PolicyRules, evaluate, record_hash
from ..risk.engine import compute_risk

FIELDS = ("id", "key", "kind", "ref_id", "pkg", "installed", "fixed", "severity", "cvss", "cvss_source",
          "exploit_known", "title", "description", "target", "layer_diff_id", "evidence", "resolution", "scan_id")


def fdict(f: Finding) -> dict:
    return {k: getattr(f, k) for k in FIELDS}


def sdict(s: Scan) -> dict:
    return {"id": s.id, "image_ref": s.image_ref, "digest": s.digest, "source": s.source, "is_demo": s.is_demo,
            "scanner": s.scanner, "scanner_version": s.scanner_version, "scanned_at": s.scanned_at,
            "created_at": s.created_at, "status": s.status, "os_family": s.os_family, "notes": s.notes,
            "has_dockerfile": bool(s.dockerfile_text)}


def get_policy(db: Session) -> Policy:
    p = db.scalar(select(Policy).where(Policy.active.is_(True)).order_by(Policy.version.desc()))
    if not p:
        p = Policy(version=1, rules=PolicyRules().model_dump(), active=True)
        db.add(p)
        db.commit()
    return p


def scan_findings(db: Session, scan_id: int) -> list[dict]:
    return [fdict(f) for f in db.scalars(select(Finding).where(Finding.scan_id == scan_id).order_by(Finding.id))]


def risk_for(db: Session, scan_id: int, findings: list[dict] | None = None, policy: Policy | None = None) -> dict:
    findings = scan_findings(db, scan_id) if findings is None else findings
    policy = policy or get_policy(db)
    base = compute_risk(findings, 0)
    nv = len(evaluate(policy.rules, findings, base["score"])["violations"])
    return compute_risk(findings, nv)


def create_scan(db: Session, parsed: dict, source: str, is_demo=False, dockerfile_text=None,
                extra_findings: list[dict] | None = None, notes=None) -> Scan:
    scan = Scan(image_ref=parsed["image_ref"], digest=parsed.get("digest"), source=source, is_demo=is_demo,
                scanner=parsed.get("scanner", "unknown"), scanner_version=parsed.get("scanner_version"),
                scanned_at=parsed.get("scanned_at") or datetime.now(timezone.utc), os_family=parsed.get("os_family"),
                layers=parsed.get("layers", []), dockerfile_text=dockerfile_text, notes=notes)
    seen = set()
    for f in parsed.get("findings", []) + (extra_findings or []):
        if f["key"] in seen:
            continue
        seen.add(f["key"])
        scan.findings.append(Finding(**f))
    db.add(scan)
    db.commit()
    return scan


def evaluate_scan(db: Session, scan: Scan) -> Decision:
    policy = get_policy(db)
    findings = scan_findings(db, scan.id)
    risk = risk_for(db, scan.id, findings, policy)
    res = evaluate(policy.rules, findings, risk["score"])
    rec = {"scan_id": scan.id, "image_ref": scan.image_ref, "digest": scan.digest, "policy_version": policy.version,
           "policy": policy.rules, "outcome": res["outcome"], "violations": res["violations"], "risk_score": risk["score"]}
    d = Decision(scan_id=scan.id, policy_version=policy.version, policy_snapshot=policy.rules, outcome=res["outcome"],
                 violations=res["violations"], risk_score=risk["score"], record_sha256=record_hash(rec))
    db.add(d)
    db.commit()
    return d


def ddict(d: Decision) -> dict:
    return {"id": d.id, "scan_id": d.scan_id, "policy_version": d.policy_version, "policy_snapshot": d.policy_snapshot,
            "outcome": d.outcome, "violations": d.violations, "risk_score": d.risk_score,
            "created_at": d.created_at, "record_sha256": d.record_sha256}


def latest_decision(db: Session, scan_id: int) -> Decision | None:
    return db.scalar(select(Decision).where(Decision.scan_id == scan_id).order_by(Decision.id.desc()))
