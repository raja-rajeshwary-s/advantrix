# Five-minute jury demo

1. **Overview** - point out the DEMO DATA banner, the pipeline, and 3 approved / 2 blocked.
2. Pick `demo/payments-svc:0.9.0` in the **active scan** dropdown, open **Findings**, click the CRITICAL row: evidence, scanner CVSS, risk points, fixed version.
3. Click **Explain and suggest**: facts vs suggestions vs uncertainty (works without an API key).
4. **Layers**: which layer holds the vulnerable `openssl`, plus the limitations panel.
5. **Policy gate** - *Evaluate this scan*: BLOCKED, exact findings, hash-stamped decision record.
6. Back in Findings, open the critical finding and **Record proposal** (status stays *proposed*).
7. **Fix to verify** - compare against `demo/payments-svc:0.9.1`: 3 resolved, 2 remaining, 1 newly introduced; gate flips to APPROVED; the remediation turns *verified*.
8. **Policy gate** - tick "Block high with fix", save, evaluate `demo/web-frontend:2.1.0`: approved becomes blocked (backend-enforced).
9. **Evidence** - generate report and receipt, download, verify the hash; change one byte and verify again: no match.
10. **Inspect** - upload a real `trivy image --format json` report to show a live (non-demo) record.
