from typing import Optional
from pydantic import BaseModel, Field


class LiveScanIn(BaseModel):
    image_ref: str = Field(min_length=1, max_length=256)


class DockerfileIn(BaseModel):
    text: str = Field(min_length=1, max_length=200_000)
    image_ref: Optional[str] = Field(default=None, max_length=256)


class RemediationIn(BaseModel):
    finding_id: int
    proposed_change: str = Field(min_length=3, max_length=2000)


class CompareIn(BaseModel):
    before_scan_id: int
    after_scan_id: int


class ReportIn(BaseModel):
    kind: str = Field(pattern="^(report|receipt)$")
    compare_with_scan_id: Optional[int] = None


class PolicyIn(BaseModel):
    name: Optional[str] = Field(default=None, max_length=128)
    rules: dict
