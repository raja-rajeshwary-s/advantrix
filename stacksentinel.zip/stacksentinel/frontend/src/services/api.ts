import { useCallback, useEffect, useState } from "react";
export type J = any;
async function req(path: string, init?: RequestInit) {
  const r = await fetch("/api" + path, init);
  if (!r.ok) {
    let m = `Request failed (${r.status})`;
    try { const j = await r.json(); m = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail); } catch { /* keep default */ }
    throw new Error(m);
  }
  return r;
}
export const get = (p: string): Promise<J> => req(p).then((r) => r.json());
export const send = (p: string, method: string, body?: unknown): Promise<J> =>
  req(p, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) }).then((r) => r.json());
export const upload = (p: string, form: FormData): Promise<J> => req(p, { method: "POST", body: form }).then((r) => r.json());

export function useAsync<T = J>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setLoading(true);
    fn().then((d) => { if (live) { setData(d); setError(null); } }).catch((e) => live && setError(e.message)).finally(() => live && setLoading(false));
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, error, loading, reload: useCallback(() => setTick((t) => t + 1), []) };
}
