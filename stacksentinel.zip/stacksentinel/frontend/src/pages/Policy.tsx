import { useEffect, useState } from "react";
import { J, get, send, useAsync } from "../services/api";
import { Btn, Card, DemoTag, Decision, Err, Loading, Mono, PageHead, SevBadge, fmt, short } from "../components/ui";
import { useApp } from "../components/Shell";

export default function Policy() {
  const { scanId, scan, refresh, openFinding } = useApp();
  const pol = useAsync(() => get("/policy"), []);
  const hist = useAsync(() => (scanId ? get(`/scans/${scanId}/decisions`) : Promise.resolve([])), [scanId]);
  const [r, setR] = useState<J | null>(null);
  const [banned, setBanned] = useState("");
  const [maxHigh, setMaxHigh] = useState("");
  const [maxRisk, setMaxRisk] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [latest, setLatest] = useState<J | null>(null);
  useEffect(() => { if (pol.data) { setR(pol.data.rules); setBanned((pol.data.rules.prohibited_rules ?? []).join(", ")); setMaxHigh(pol.data.rules.max_high ?? ""); setMaxRisk(pol.data.rules.max_risk_score ?? ""); } }, [pol.data]);
  useEffect(() => setLatest(null), [scanId]);
  if (!r) return pol.error ? <Err msg={pol.error} /> : <Loading />;
  const tog = (k: string) => setR({ ...r, [k]: !r[k] });
  const save = async () => { setErr(null); setMsg(null); try {
    const rules = { ...r, prohibited_rules: banned.split(",").map((x) => x.trim()).filter(Boolean), max_high: maxHigh === "" ? null : Number(maxHigh), max_risk_score: maxRisk === "" ? null : Number(maxRisk) };
    const p = await send("/policy", "PUT", { rules }); setMsg(`Saved as policy version ${p.version}. Re-evaluate a scan to apply it.`); pol.reload(); } catch (e: any) { setErr(e.message); } };
  const evaluate = async () => { setErr(null); try { setLatest(await send(`/scans/${scanId}/evaluate`, "POST")); hist.reload(); refresh(); } catch (e: any) { setErr(e.message); } };
  const rows: [string, string, string][] = [["block_critical", "Block critical vulnerabilities", "Any CRITICAL finding fails the gate."], ["block_high_with_fix", "Block high vulnerabilities that have a fix", "HIGH findings whose scanner lists a fixed version fail the gate."], ["block_root", "Block root execution", "Fails when the image is configured to run as root."]];
  const d = latest ?? hist.data?.[0];
  return (<>
    <PageHead title="Security policy gate" sub="Rules are stored and enforced in the backend. Every evaluation writes an auditable decision record tied to the policy version." right={scan?.is_demo ? <DemoTag /> : undefined} />
    <Err msg={err} />
    <div className="grid gap-5 md:grid-cols-2">
      <Card title={`Policy rules (version ${pol.data?.version})`}><div className="space-y-3 text-[13px]">
        {rows.map(([k, t, s]) => (<label key={k} className="flex cursor-pointer items-start gap-3"><input type="checkbox" className="mt-1" checked={!!r[k]} onChange={() => tog(k)} /><span><span className="block">{t}</span><span className="text-[12px] text-mute">{s}</span></span></label>))}
        <label className="block text-mute">Maximum HIGH findings (blank = no limit)<input type="number" min={0} value={maxHigh} onChange={(e) => setMaxHigh(e.target.value)} className="ml-2 w-20 border border-line bg-ink p-1 text-ivory" /></label>
        <label className="block text-mute">Maximum risk score (blank = no limit)<input type="number" min={0} max={100} value={maxRisk} onChange={(e) => setMaxRisk(e.target.value)} className="ml-2 w-20 border border-line bg-ink p-1 text-ivory" /></label>
        <label className="block text-mute">Prohibited rule IDs (comma separated)<input value={banned} onChange={(e) => setBanned(e.target.value)} placeholder="SS-DF-004, SS-DF-005" className="mt-1 w-full border border-line bg-ink p-1.5 font-mono text-[12px] text-ivory" /></label>
        <div className="flex items-center gap-3 pt-1"><Btn kind="primary" onClick={save}>Save new policy version</Btn>{msg && <span className="text-[12px] text-lime">{msg}</span>}</div></div></Card>
      <Card title="Gate decision" aside={<Btn kind="primary" onClick={evaluate} disabled={!scanId}>Evaluate this scan</Btn>}>
        {!d ? <p className="text-mute">No decision recorded for this scan yet. Evaluate it against the active policy.</p> : (<div className="space-y-3">
          <div className="flex items-center gap-3"><Decision d={d.outcome} /><Mono className="text-mute">policy v{d.policy_version} - risk {d.risk_score} - {fmt(d.created_at)}</Mono></div>
          {d.violations.length === 0 ? <p className="text-[13px] text-lime">No rule was violated. The image is approved for deployment under this policy.</p> : d.violations.map((v: any) => (
            <div key={v.rule} className="border border-crit/50 bg-crit/5 p-3"><div className="font-mono text-[12px] text-crit">{v.rule}</div><p className="text-[13px]">{v.message}</p>
              <div className="mt-2 flex flex-wrap gap-2">{v.findings.map((f: any) => <button key={f.id} onClick={() => openFinding(f.id)} className="border border-line px-2 py-1 hover:border-lime"><Mono>{f.ref_id}{f.pkg ? ` ${f.pkg}` : ""}</Mono> <SevBadge s={f.severity} /></button>)}</div></div>))}
          <div className="text-[12px] text-mute">Record SHA-256 <Mono className="text-ivory">{short(d.record_sha256, 24)}...</Mono></div></div>)}
      </Card>
    </div>
    <Card title="Audit trail for this scan" className="mt-5">{!hist.data?.length ? <p className="text-mute">No decisions yet.</p> : (
      <table className="w-full text-left text-[13px]"><thead className="text-mute"><tr className="border-b border-line"><th className="py-1.5">When</th><th>Decision</th><th>Policy</th><th>Violations</th><th>Record hash</th></tr></thead>
        <tbody>{hist.data.map((x: any) => <tr key={x.id} className="border-b border-line/60"><td className="py-1.5"><Mono>{fmt(x.created_at)}</Mono></td><td><Decision d={x.outcome} /></td><td><Mono>v{x.policy_version}</Mono></td><td><Mono>{x.violations.map((v: any) => v.rule).join(", ") || "-"}</Mono></td><td><Mono>{short(x.record_sha256)}</Mono></td></tr>)}</tbody></table>)}</Card>
  </>);
}
