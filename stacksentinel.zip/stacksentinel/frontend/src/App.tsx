import { Route, Routes } from "react-router-dom";
import Shell from "./components/Shell";
import Overview from "./pages/Overview";
import Inspect from "./pages/Inspect";
import Layers from "./pages/Layers";
import Findings from "./pages/Findings";
import Risk from "./pages/Risk";
import Policy from "./pages/Policy";
import Verify from "./pages/Verify";
import Evidence from "./pages/Evidence";

export default function App() {
  return (
    <Shell>
      <Routes>
        <Route path="/" element={<Overview />} /><Route path="/inspect" element={<Inspect />} /><Route path="/layers" element={<Layers />} />
        <Route path="/findings" element={<Findings />} /><Route path="/risk" element={<Risk />} /><Route path="/policy" element={<Policy />} />
        <Route path="/verify" element={<Verify />} /><Route path="/evidence" element={<Evidence />} />
      </Routes>
    </Shell>
  );
}
