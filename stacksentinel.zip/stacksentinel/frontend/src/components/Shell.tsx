import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { Activity, Boxes, FileCheck2, Gauge, Layers, ListChecks, Search, ShieldCheck, Wrench } from "lucide-react";
import { J, get, useAsync } from "../services/api";
import { DemoTag } from "./ui";
import FindingInspector from "./FindingInspector";

interface Ctx { scans: J[]; scanId: number | null; setScanId: (n: number) => void; refresh: () => void; openFinding: (id: number) => void; caps: J | null; scan: J | null; }
const AppCtx = createContext<Ctx>(null as unknown as Ctx);
export const useApp = () => useContext(AppCtx);

const NAV = [
  { to: "/", label: "Overview", icon: Activity }, { to: "/inspect", label: "Inspect", icon: Search }, { to: "/layers", label: "Layers", icon: Layers },
  { to: "/findings", label: "Findings", icon: ListChecks }, { to: "/risk", label: "Risk engine", icon: Gauge }, { to: "/policy", label: "Policy gate", icon: ShieldCheck },
  { to: "/verify", label: "Fix to verify", icon: Wrench }, { to: "/evidence", label: "Evidence", icon: FileCheck2 },
];

export default function Shell({ children }: { children: ReactNode }) {
  const scansQ = useAsync(() => get("/scans?page_size=200"), []);
  const caps = useAsync(() => get("/capabilities"), []);
  const [scanId, setScanId] = useState<number | null>(null);
  const [fid, setFid] = useState<number | null>(null);
  const scans: J[] = scansQ.data?.items ?? [];
  useEffect(() => { if (scanId === null && scans.length) setScanId((scans.find((s) => s.source !== "dockerfile") ?? scans[0]).id); }, [scans, scanId]);
  const scan = scans.find((s) => s.id === scanId) ?? null;
  const c = caps.data;
  const live = scans.filter((s) => !s.is_demo).length, demo = scans.filter((s) => s.is_demo).length;
  return (
    <AppCtx.Provider value={{ scans, scanId, setScanId, refresh: scansQ.reload, openFinding: setFid, caps: c, scan }}>
      <div className="min-h-screen md:grid md:grid-cols-[232px_1fr]">
        <aside className="border-b border-line bg-graphite md:sticky md:top-0 md:h-screen md:border-b-0 md:border-r">
          <div className="px-5 pb-3 pt-5"><div className="flex items-center gap-2"><Boxes size={20} className="text-lime" /><span className="font-display text-[22px]">StackSentinel</span></div>
            <p className="mt-1 text-[11px] leading-snug text-mute">Every layer has a story. Every deployment must earn trust.</p></div>
          <nav aria-label="Primary" className="relative flex gap-1 overflow-x-auto px-3 pb-3 md:block md:pl-8 md:pr-3">
            <span aria-hidden className="absolute bottom-3 left-[22px] top-1 hidden w-px bg-line md:block" />
            {NAV.map(({ to, label, icon: I }) => (
              <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => `relative flex items-center gap-2 whitespace-nowrap px-3 py-2 text-[14px] ${isActive ? "text-lime" : "text-ivory/80 hover:text-ivory"}`}>
                {({ isActive }) => (<><span aria-hidden className={`absolute -left-[13px] top-1/2 hidden h-2.5 w-2.5 -translate-y-1/2 border md:block ${isActive ? "border-lime bg-lime" : "border-mute bg-graphite"}`} /><I size={15} />{label}</>)}
              </NavLink>))}
          </nav>
        </aside>
        <div className="min-w-0">
          <div className="sticky top-0 z-30 flex flex-wrap items-center gap-x-5 gap-y-1 border-b border-line bg-ink/95 px-5 py-2 font-mono text-[11px] text-mute backdrop-blur">
            <span>scanner: <b className={c?.trivy_installed ? "text-lime" : "text-amber"}>{c ? (c.trivy_installed ? "trivy ready (live scans on)" : "trivy not installed - report import mode") : "..."}</b></span>
            <span>assistant: <b className="text-ivory">{c ? (c.llm_configured ? "LLM + rules" : "rule-based") : "..."}</b></span>
            <span>db: <b className="text-ivory">{c?.database ?? "..."}</b></span>
            <span>records: <b className="text-ivory">{live} live</b> / <b className="text-amber">{demo} demo</b></span>
            <label className="ml-auto flex items-center gap-2">active scan
              <select aria-label="Active scan" value={scanId ?? ""} onChange={(e) => setScanId(Number(e.target.value))} className="max-w-[260px] border border-line bg-graphite px-2 py-1 text-ivory">
                {scans.map((s) => <option key={s.id} value={s.id}>#{s.id} {s.image_ref}{s.is_demo ? " [DEMO]" : ""}</option>)}
              </select></label>
            {scan?.is_demo && <DemoTag />}
          </div>
          <main className="mx-auto max-w-[1180px] px-5 py-6">{children}</main>
        </div>
      </div>
      <FindingInspector id={fid} onClose={() => setFid(null)} />
    </AppCtx.Provider>
  );
}
