"""Seeds clearly-labelled SYNTHETIC demo scans by running the real parser/policy/risk code on fixtures."""
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..core.config import DEMO_DIR
from ..models.models import Finding, Remediation, Scan
from ..scanners.dockerfile import analyse_dockerfile
from ..scanners.trivy import parse_trivy_report
from .core import create_scan, evaluate_scan

ORDER = ["clean-api-1.4.2", "web-frontend-2.1.0", "payments-svc-0.9.0", "legacy-batch-3.0.0", "payments-svc-0.9.1"]


def seed_demo(db: Session) -> None:
    if db.scalar(select(func.count(Scan.id)).where(Scan.is_demo.is_(True))):
        return
    ids = {}
    for name in ORDER:
        p = DEMO_DIR / f"{name}.trivy.json"
        if not p.exists():
            continue
        parsed = parse_trivy_report(p.read_bytes())
        df = DEMO_DIR / f"{name.rsplit('-', 1)[0]}.Dockerfile"
        df_text = df.read_text() if df.exists() else None
        extra = analyse_dockerfile(df_text) if df_text else []
        s = create_scan(db, parsed, "trivy-report+dockerfile" if df_text else "trivy-report", True, df_text, extra,
                        notes="DEMO DATA: synthetic fixture parsed by the real pipeline. Not a real scan.")
        evaluate_scan(db, s)
        ids[name] = s.id
    # one proposed remediation on the blocked image, left unverified until the user runs the comparison
    if "payments-svc-0.9.0" in ids:
        f = db.scalar(select(Finding).where(Finding.scan_id == ids["payments-svc-0.9.0"], Finding.severity == "CRITICAL"))
        if f:
            db.add(Remediation(scan_id=f.scan_id, finding_id=f.id, finding_key=f.key,
                               proposed_change="Upgrade openssl to 3.1.4-r0 by rebuilding on the patched base image."))
            db.commit()
