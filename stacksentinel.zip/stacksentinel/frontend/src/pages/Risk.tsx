import { get, useAsync } from "../services/api";
import { Card, DemoTag, Err, Loading, Mono, PageHead } from "../components/ui";
import { useApp } from "../components/Shell";

const CLS: Record<string, string> = { Clean: "#b8f03c", Low: "#7f9a6a", Medium: "#c9b458", High: "#f0a83a", Critical: "#e5484d" };

export default function Risk() {
  const { scanId, scan, openFinding } = useApp();
  const q = useAsync(() => (scanId ? get(`/scans/${scanId}/risk`) : Promise.resolve(null)), [scanId]);
  const r = q.data;
  if (q.loading) return <Loading />;
  if (!r) return <Err msg={q.error} />;
  return (<>
    <PageHead title="Explainable risk engine" sub="A deterministic rule-based model. Scanner severity is an input; the platform score below is a separate aggregate. No machine-learning model is used or claimed." right={scan?.is_demo ? <DemoTag /> : undefined} />
    <div className="mb-5 grid gap-5 md:grid-cols-[260px_1fr]">
      <Card><div className="text-[12px] text-mute">Platform risk score</div><div className="font-display text-[64px] leading-none" style={{ color: CLS[r.classification] }}>{r.score}</div>
        <div className="mt-1 font-display text-[20px]" style={{ color: CLS[r.classification] }}>{r.classification}</div><div className="mt-3 h-1.5 bg-line"><div className="h-full" style={{ width: `${r.score}%`, background: CLS[r.classification] }} /></div>
        <div className="mt-1 flex justify-between font-mono text-[10px] text-mute"><span>0</span><span>100</span></div></Card>
      <Card title="Why this classification"><p className="mb-3 text-[14px]">{r.explanation}</p>
        <Mono className="block text-mute">{r.formula}</Mono><Mono className="mt-1 block text-mute">model {r.model} - identical inputs always produce this score</Mono></Card>
    </div>
    <Card title="Scoring factors and contributions" className="mb-5"><div className="space-y-2">{r.factors.map((f: any) => (
      <div key={f.factor}><div className="flex justify-between text-[13px]"><span>{f.factor} <span className="text-mute">({f.count})</span></span><Mono>{f.points} pts / {f.share_pct}%</Mono></div>
        <div className="h-2 bg-line"><div className="h-full bg-lime" style={{ width: `${f.share_pct}%` }} /></div></div>))}
      {r.factors.length === 0 && <p className="text-mute">No findings, so no points were assigned.</p>}</div></Card>
    <div className="grid gap-5 md:grid-cols-2">
      <Card title="Top contributing findings (evidence)"><ul className="space-y-3 text-[13px]">{r.top_contributors.map((t: any) => (<li key={t.finding_id}>
        <button onClick={() => openFinding(t.finding_id)} className="font-mono text-lime hover:underline">#{t.finding_id} {t.ref_id} {t.pkg ?? ""}</button> <Mono className="text-mute">{t.points} pts</Mono>
        <div className="text-[12px] text-mute">{t.reasoning.join("; ")}</div></li>))}</ul></Card>
      <Card title="Missing information (stated, not assumed)"><ul className="list-disc space-y-1 pl-5 text-[13px] text-mute">{r.missing_information.map((m: string) => <li key={m}>{m}</li>)}</ul></Card>
    </div>
  </>);
}
