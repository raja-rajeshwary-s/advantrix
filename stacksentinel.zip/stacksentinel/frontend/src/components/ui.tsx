import { ReactNode } from "react";
import { X } from "lucide-react";

export const SEV_COLOR: Record<string, string> = { CRITICAL: "#e5484d", HIGH: "#f0a83a", MEDIUM: "#c9b458", LOW: "#7f9a6a", UNKNOWN: "#77766a" };
export const SEVS = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"];

export const Mono = ({ children, className = "" }: { children: ReactNode; className?: string }) => <span className={`font-mono text-[12px] ${className}`}>{children}</span>;

export const SevBadge = ({ s }: { s: string }) => (
  <span className="inline-flex items-center gap-1.5 font-mono text-[11px]" style={{ color: SEV_COLOR[s] }}>
    <span className="h-2 w-2" style={{ background: SEV_COLOR[s] }} />{s}
  </span>
);

export const DemoTag = () => <span className="border border-amber px-1.5 py-px font-mono text-[10px] text-amber" title="Seeded synthetic record, not a real scan">DEMO DATA</span>;

export const Decision = ({ d }: { d?: string }) => {
  const c = d === "APPROVED" ? "#b8f03c" : d === "BLOCKED" ? "#e5484d" : "#9a9887";
  return <span className="font-mono text-[11px] font-medium" style={{ color: c, border: `1px solid ${c}`, padding: "1px 6px" }}>{d === "NOT_EVALUATED" ? "NOT EVALUATED" : d || "-"}</span>;
};

export const Card = ({ title, aside, children, className = "" }: { title?: string; aside?: ReactNode; children: ReactNode; className?: string }) => (
  <section className={`border border-line bg-graphite ${className}`}>
    {title && <header className="flex items-center justify-between border-b border-line px-4 py-2.5"><h3 className="font-display text-[17px]">{title}</h3>{aside}</header>}
    <div className="p-4">{children}</div>
  </section>
);

export const Btn = ({ children, onClick, kind = "ghost", disabled, title, type = "button" }: { children: ReactNode; onClick?: () => void; kind?: "primary" | "ghost" | "danger"; disabled?: boolean; title?: string; type?: "button" | "submit" }) => {
  const k = kind === "primary" ? "bg-lime text-ink hover:bg-[#cdfa66]" : kind === "danger" ? "border border-crit text-crit hover:bg-crit/10" : "border border-line hover:border-mute";
  return <button type={type} title={title} disabled={disabled} onClick={onClick} className={`px-3 py-1.5 text-[13px] font-semibold disabled:cursor-not-allowed disabled:opacity-40 ${k}`}>{children}</button>;
};

export const PageHead = ({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) => (
  <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
    <div><h1 className="font-display text-[30px] leading-tight">{title}</h1>{sub && <p className="mt-1 max-w-2xl text-[14px] text-mute">{sub}</p>}</div>{right}
  </div>
);

export const Err = ({ msg }: { msg: string | null }) => msg ? <div role="alert" className="border border-crit bg-crit/10 px-3 py-2 text-[13px] text-crit">{msg}</div> : null;
export const Empty = ({ children }: { children: ReactNode }) => <div className="border border-dashed border-line px-4 py-8 text-center text-[14px] text-mute">{children}</div>;
export const Loading = () => <div className="py-8 text-center font-mono text-[12px] text-mute">loading...</div>;

export const Drawer = ({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) => open ? (
  <div className="fixed inset-0 z-40 flex justify-end bg-black/60" onClick={onClose}>
    <aside role="dialog" aria-label={title} className="drawer h-full w-full max-w-[560px] overflow-y-auto border-l border-line bg-ink" onClick={(e) => e.stopPropagation()}>
      <div className="sticky top-0 flex items-center justify-between border-b border-line bg-ink px-5 py-3"><h2 className="font-display text-[20px]">{title}</h2>
        <button aria-label="Close" onClick={onClose} className="p-1 hover:text-lime"><X size={18} /></button></div>
      <div className="p-5">{children}</div>
    </aside>
  </div>
) : null;

export const fmt = (d?: string) => d ? new Date(d).toLocaleString() : "-";
export const short = (h?: string | null, n = 14) => h ? h.replace("sha256:", "").slice(0, n) : "-";
