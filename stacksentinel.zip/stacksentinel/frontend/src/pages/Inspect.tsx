import { FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { J, get, send, upload, useAsync } from "../services/api";
import { Btn, Card, DemoTag, Decision, Err, Mono, PageHead, fmt } from "../components/ui";
import { useApp } from "../components/Shell";

export default function Inspect() {
  const { caps, scans, setScanId, refresh } = useApp();
  const nav = useNavigate();
  const [ref, setRef] = useState("");
  const [report, setReport] = useState<File | null>(null);
  const [df, setDf] = useState<File | null>(null);
  const [dfText, setDfText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [view, setView] = useState<number | null>(null);
  const detail = useAsync(() => (view ? get(`/scans/${view}`) : Promise.resolve(null)), [view]);

  const done = (r: J, what: string) => { setOk(`${what}: scan #${r.scan.id} stored with ${r.findings} findings.`); setScanId(r.scan.id); refresh(); };
  const run = async (fn: () => Promise<J>, what: string, go = true) => {
    setBusy(true); setErr(null); setOk(null);
    try { const r = await fn(); done(r, what); if (go) nav("/findings"); } catch (e: any) { setErr(e.message); }
    setBusy(false);
  };
  const live = (e: FormEvent) => { e.preventDefault(); run(() => send("/scans/live", "POST", { image_ref: ref.trim() }), "Live Trivy scan"); };
  const uploadReport = () => { const f = new FormData(); f.append("file", report!); if (df) f.append("dockerfile", df); if (ref.trim()) f.append("image_ref", ref.trim()); run(() => upload("/scans/trivy-report", f), "Report imported"); };
  const analyseDf = () => { const f = new FormData(); if (df && !dfText) f.append("file", df); else f.append("text", dfText); run(() => upload("/scans/dockerfile", f), "Dockerfile analysed"); };
  const liveOn = !!caps?.live_scan_available;

  return (<>
    <PageHead title="Container inspection" sub="Bring in a scan. The platform only reports a scan as live when Trivy actually ran here; imported reports are labelled as imports." />
    <Err msg={err} />{ok && <div className="mb-3 border border-lime/50 bg-lime/10 px-3 py-2 text-[13px] text-lime">{ok}</div>}
    <div className="grid gap-5 md:grid-cols-3">
      <Card title="Scan an image">
        <form onSubmit={live} className="space-y-3"><label className="block text-[13px] text-mute">Image reference
          <input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="registry/app:1.2.3" className="mt-1 w-full border border-line bg-ink p-2 font-mono text-[12px] text-ivory" /></label>
          <Btn type="submit" kind="primary" disabled={!liveOn || busy || !ref.trim()} title={liveOn ? "" : "Trivy is not installed on this server"}>Run Trivy scan</Btn>
          {!liveOn && <p className="text-[12px] text-amber">Trivy is not installed on this server, so live scans are unavailable. Import a report instead; nothing is simulated.</p>}</form>
      </Card>
      <Card title="Import a Trivy JSON report">
        <div className="space-y-3 text-[13px]">
          <label className="block text-mute">Report (.json)<input type="file" accept=".json,application/json" onChange={(e) => setReport(e.target.files?.[0] ?? null)} className="mt-1 block w-full text-[12px]" /></label>
          <label className="block text-mute">Dockerfile (optional, merged)<input type="file" onChange={(e) => setDf(e.target.files?.[0] ?? null)} className="mt-1 block w-full text-[12px]" /></label>
          <label className="block text-mute">Image name override (optional)<input value={ref} onChange={(e) => setRef(e.target.value)} className="mt-1 w-full border border-line bg-ink p-2 font-mono text-[12px] text-ivory" /></label>
          <Btn kind="primary" disabled={!report || busy} onClick={uploadReport}>Import report</Btn>
          <p className="text-[12px] text-mute">Create one with: <Mono>trivy image --format json -o report.json IMAGE</Mono></p></div>
      </Card>
      <Card title="Analyse a Dockerfile">
        <div className="space-y-3 text-[13px]">
          <textarea aria-label="Dockerfile text" value={dfText} onChange={(e) => setDfText(e.target.value)} rows={6} placeholder={"FROM node:latest\nRUN curl -s https://x | sh"} className="w-full border border-line bg-ink p-2 font-mono text-[12px]" />
          <label className="block text-mute">or upload a file<input type="file" onChange={(e) => setDf(e.target.files?.[0] ?? null)} className="mt-1 block w-full text-[12px]" /></label>
          <Btn kind="primary" disabled={busy || (!dfText.trim() && !df)} onClick={analyseDf}>Analyse statically</Btn>
          <p className="text-[12px] text-mute">Read as text only. Never built or executed.</p></div>
      </Card>
    </div>
    <Card title="Previously completed scans" className="mt-5">
      <div className="overflow-x-auto"><table className="w-full text-left text-[13px]"><thead className="text-mute"><tr className="border-b border-line"><th className="py-1.5">#</th><th>Image</th><th>Source</th><th>Scanner</th><th>Scanned</th><th>Findings</th><th>Gate</th></tr></thead>
        <tbody>{scans.map((s) => (<tr key={s.id} onClick={() => setView(s.id)} className={`cursor-pointer border-b border-line/60 hover:bg-panel ${view === s.id ? "bg-panel" : ""}`}>
          <td className="py-2"><Mono>{s.id}</Mono></td><td><Mono>{s.image_ref}</Mono> {s.is_demo && <DemoTag />}</td><td><Mono>{s.source}</Mono></td><td><Mono>{s.scanner}</Mono></td><td><Mono>{fmt(s.scanned_at)}</Mono></td><td><Mono>{s.findings}</Mono></td><td><Decision d={s.decision} /></td></tr>))}</tbody></table></div>
    </Card>
    {detail.data && (<Card title={`Scan #${detail.data.id} details`} className="mt-5" aside={<Btn onClick={() => { setScanId(detail.data.id); nav("/findings"); }}>Open findings</Btn>}>
      <div className="grid gap-5 md:grid-cols-2"><div className="space-y-1 text-[13px]">
        <div><span className="text-mute">Digest </span><Mono className="break-all">{detail.data.digest ?? "not available"}</Mono></div>
        <div><span className="text-mute">Scanner </span><Mono>{detail.data.scanner} {detail.data.scanner_version ?? "(version not recorded)"}</Mono></div>
        <div><span className="text-mute">OS </span><Mono>{detail.data.os_family ?? "unknown"}</Mono></div>
        {detail.data.notes && <p className="pt-2 text-[12px] text-amber">{detail.data.notes}</p>}
        <div className="flex flex-wrap gap-3 pt-2">{Object.entries(detail.data.severity).map(([k, v]) => <Mono key={k}>{k}: {String(v)}</Mono>)}</div></div>
        {detail.data.dockerfile_text && <pre className="max-h-56 overflow-auto border border-line bg-ink p-2 font-mono text-[11px]">{detail.data.dockerfile_text}</pre>}</div>
    </Card>)}
  </>);
}
