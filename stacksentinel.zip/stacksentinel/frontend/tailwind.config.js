export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink: "#111210", graphite: "#1a1c19", panel: "#20231f", line: "#33372f", ivory: "#ece6d4", mute: "#9a9887", lime: "#b8f03c", amber: "#f0a83a", crit: "#e5484d" },
    fontFamily: { display: ['"Fraunces Variable"', "Georgia", "serif"], sans: ['"IBM Plex Sans"', "system-ui", "sans-serif"], mono: ['"IBM Plex Mono"', "ui-monospace", "monospace"] },
  } },
  plugins: [],
};
