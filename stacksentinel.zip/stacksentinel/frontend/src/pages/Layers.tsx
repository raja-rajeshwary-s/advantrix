import { useState } from "react";
import { get, useAsync } from "../services/api";
import { Card, Empty, Err, Loading, Mono, PageHead, SEV_COLOR, SEVS } from "../components/ui";
import { useApp } from "../components/Shell";

const worst = (c: Record<string, number>) => SEVS.find((s) => c[s] > 0);

export default function Layers() {
  const { scanId, openFinding } = useApp();
  const q = useAsync(() => (scanId ? get(`/scans/${scanId}/layers`) : Promise.resolve(null)), [scanId]);
  const [open, setOpen] = useState<number | null>(null);
  const d = q.data;
  if (q.loading) return <Loading />;
  if (!d) return <Err msg={q.error} />;
  const max = Math.max(1, ...d.layers.map((l: any) => l.points));
  const stack = [...d.layers].reverse();
  return (<>
    <PageHead title="Layer intelligence" sub={`${d.scan.image_ref} - the newest layer is on top. Block height follows each layer's share of risk points; the rail marks each layer's worst severity.`} />
    {d.layers.length === 0 ? <Empty>This scan has no layer metadata, so no stack can be drawn. Import a Trivy image report to see layers.</Empty> : (
      <div className="relative pl-10"><span aria-hidden className="absolute bottom-2 left-[13px] top-2 w-px bg-line" />
        {stack.map((l: any) => { const w = worst(l.counts); const h = 64 + Math.round((l.points / max) * 110); const isOpen = open === l.index; return (
          <div key={l.diff_id} className="relative mb-1.5">
            <span aria-hidden className="absolute -left-[33px] top-4 h-3 w-3" style={{ background: w ? SEV_COLOR[w] : "#b8f03c" }} />
            <button onClick={() => setOpen(isOpen ? null : l.index)} aria-expanded={isOpen} style={{ minHeight: h, borderLeft: `4px solid ${w ? SEV_COLOR[w] : "#b8f03c"}` }}
              className="block w-full border border-line bg-graphite px-4 py-3 text-left hover:bg-panel">
              <div className="flex flex-wrap items-baseline justify-between gap-2"><Mono className="text-mute">layer {l.index} / {l.diff_id.slice(7, 19)}</Mono>
                <span className="font-mono text-[11px]">{SEVS.filter((s) => l.counts[s]).map((s) => <span key={s} className="mr-2" style={{ color: SEV_COLOR[s] }}>{l.counts[s]} {s}</span>)}{!w && <span className="text-lime">no findings</span>}</span></div>
              <div className="mt-1 break-all font-mono text-[12px]">{l.created_by ?? "build command not recorded in scan data"}</div>
              <div className="mt-1 text-[12px] text-mute">{l.packages.length ? `Affected packages: ${l.packages.join(", ")}` : "No vulnerable packages attributed here"}{l.fixable ? ` - ${l.fixable} fixable by upgrading the package` : ""}</div>
            </button>
            {isOpen && l.findings.length > 0 && <div className="border border-t-0 border-line bg-ink p-3"><div className="flex flex-wrap gap-2">{l.findings.map((f: any) => (
              <button key={f.id} onClick={() => openFinding(f.id)} className="border border-line px-2 py-1 text-left hover:border-lime"><Mono className="block">{f.ref_id}</Mono><span className="text-[11px]" style={{ color: SEV_COLOR[f.severity] }}>{f.severity}</span> <Mono className="text-mute">{f.pkg} {f.fixed ? `-> ${f.fixed}` : "no fix"}</Mono></button>))}</div></div>}
          </div>); })}
      </div>)}
    {d.unattributed.count > 0 && <Card title={`Unattributed vulnerabilities (${d.unattributed.count})`} className="mt-5"><div className="flex flex-wrap gap-2">{d.unattributed.findings.map((f: any) => <button key={f.id} onClick={() => openFinding(f.id)} className="border border-line px-2 py-1 hover:border-lime"><Mono>{f.ref_id} {f.pkg}</Mono></button>)}</div></Card>}
    {d.config_findings.length > 0 && <Card title="Configuration findings (not tied to a layer)" className="mt-5"><ul className="space-y-1">{d.config_findings.map((f: any) => <li key={f.id}><button onClick={() => openFinding(f.id)} className="text-left hover:text-lime"><Mono className="mr-2">{f.ref_id}</Mono>{f.title} <span className="text-[11px]" style={{ color: SEV_COLOR[f.severity] }}>{f.severity}</span></button></li>)}</ul></Card>}
    <Card title="What this view cannot tell you" className="mt-5"><ul className="list-disc space-y-1 pl-5 text-[13px] text-mute">{d.limitations.map((x: string) => <li key={x}>{x}</li>)}</ul></Card>
  </>);
}
