import re
import shutil
from collections import Counter
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session
from ..core import config
from ..core.db import get_db
from ..models.models import Decision, Finding, Policy, Remediation, Report, Scan
from ..policies.engine import PolicyRules
from ..reports.report import build_receipt, build_report, sha256_text
from ..risk.engine import finding_points
from ..scanners.dockerfile import analyse_dockerfile, first_from_image
from ..scanners.trivy import IMAGE_REF_RE, ParseError, parse_trivy_report, run_live_scan, trivy_available
from ..schemas.api import CompareIn, DockerfileIn, LiveScanIn, PolicyIn, RemediationIn, ReportIn
from ..services.assistant import deterministic_explain, llm_explain
from ..services.compare import compare_findings
from ..services.core import (ddict, evaluate_scan, fdict, get_policy, latest_decision, risk_for, scan_findings, sdict, create_scan)

router = APIRouter(prefix="/api")
SEV = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"]


async def _read(file: UploadFile, limit: int | None = None) -> bytes:
    limit = limit or config.MAX_UPLOAD_BYTES
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File exceeds the {limit // 1024} KB limit.")
    if not data:
        raise HTTPException(400, "File is empty.")
    return data


def _text(data: bytes) -> str:
    try:
        t = data.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "Dockerfile must be UTF-8 text.")
    if "\x00" in t:
        raise HTTPException(400, "File looks binary, not a Dockerfile.")
    return t


def _scan(db: Session, scan_id: int) -> Scan:
    s = db.get(Scan, scan_id)
    if not s:
        raise HTTPException(404, "Scan not found.")
    return s


def _verif(db: Session, scan_id: int) -> dict[int, str]:
    return {r.finding_id: r.status for r in db.scalars(select(Remediation).where(Remediation.scan_id == scan_id).order_by(Remediation.id))}


# ---------- system ----------
@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/capabilities")
def capabilities(db: Session = Depends(get_db)):
    return {"trivy_installed": bool(trivy_available()), "docker_installed": bool(shutil.which("docker")),
            "cosign_installed": bool(shutil.which("cosign")), "cosign_signing_implemented": False,
            "llm_configured": bool(config.ANTHROPIC_API_KEY), "database": db.bind.dialect.name,
            "max_upload_kb": config.MAX_UPLOAD_BYTES // 1024,
            "live_scan_available": bool(trivy_available()),
            "notes": ["Live image scanning requires Trivy on the server.", "Cosign verification/signing is not implemented in this prototype."]}


@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    scans = list(db.scalars(select(Scan).order_by(Scan.id.desc())))
    latest: dict[str, Scan] = {}
    for s in scans:
        if s.source != "dockerfile" or s.image_ref not in latest:
            latest.setdefault(s.image_ref, s)
    rows, sev, pk = [], Counter(), Counter()
    for ref, s in latest.items():
        fs = scan_findings(db, s.id)
        d = latest_decision(db, s.id)
        risk = risk_for(db, s.id, fs)
        sev.update(f["severity"] for f in fs)
        pk.update(f["pkg"] for f in fs if f["pkg"])
        rows.append({"scan": sdict(s), "decision": d.outcome if d else "NOT_EVALUATED", "risk_score": risk["score"],
                     "risk_class": risk["classification"], "critical": sum(f["severity"] == "CRITICAL" for f in fs),
                     "high": sum(f["severity"] == "HIGH" for f in fs), "findings": len(fs)})
    def cnt(pred): return sum(1 for r in rows if pred(r))
    return {
        "images": {"total": len(rows), "demo": cnt(lambda r: r["scan"]["is_demo"]), "live": cnt(lambda r: not r["scan"]["is_demo"]),
                   "passing": cnt(lambda r: r["decision"] == "APPROVED"), "failing": cnt(lambda r: r["decision"] == "BLOCKED"),
                   "unevaluated": cnt(lambda r: r["decision"] == "NOT_EVALUATED")},
        "severity": {s: sev.get(s, 0) for s in SEV}, "top_packages": [{"pkg": k, "count": v} for k, v in pk.most_common(6)],
        "inventory": sorted(rows, key=lambda r: -r["risk_score"]),
        "recent": [sdict(s) for s in scans[:8]],
        "needs_remediation": [r for r in sorted(rows, key=lambda r: -r["risk_score"]) if r["decision"] == "BLOCKED"],
        "pipeline": {"build": len(rows), "scan": len(rows), "analyse": len(rows) - cnt(lambda r: r["decision"] == "NOT_EVALUATED"),
                     "approved": cnt(lambda r: r["decision"] == "APPROVED"), "blocked": cnt(lambda r: r["decision"] == "BLOCKED")},
        "system": {"live_scans_recorded": db.scalar(select(func.count(Scan.id)).where(Scan.is_demo.is_(False))) or 0,
                   "demo_scans_recorded": db.scalar(select(func.count(Scan.id)).where(Scan.is_demo.is_(True))) or 0},
    }


# ---------- scans ----------
@router.post("/scans/trivy-report")
async def upload_trivy(file: UploadFile = File(...), dockerfile: UploadFile | None = File(None), image_ref: str | None = Form(None), db: Session = Depends(get_db)):
    if not (file.filename or "").lower().endswith(".json"):
        raise HTTPException(400, "Trivy report must be a .json file.")
    data = await _read(file)
    try:
        parsed = parse_trivy_report(data)
    except ParseError as e:
        raise HTTPException(422, str(e))
    if image_ref:
        if not IMAGE_REF_RE.match(image_ref):
            raise HTTPException(422, "Invalid image reference.")
        parsed["image_ref"] = image_ref
    df_text, extra, source = None, [], "trivy-report"
    if dockerfile is not None and dockerfile.filename:
        df_text = _text(await _read(dockerfile, 200_000))
        extra = analyse_dockerfile(df_text)
        source = "trivy-report+dockerfile"
    scan = create_scan(db, parsed, source, False, df_text, extra, notes="Imported report; the platform did not run the scan itself.")
    evaluate_scan(db, scan)
    return {"scan": sdict(scan), "findings": len(scan.findings)}


@router.post("/scans/dockerfile")
async def analyse_df(file: UploadFile | None = File(None), text: str | None = Form(None), image_ref: str | None = Form(None), db: Session = Depends(get_db)):
    if file is not None and file.filename:
        t = _text(await _read(file, 200_000))
    elif text:
        if len(text) > 200_000:
            raise HTTPException(413, "Dockerfile text too large.")
        t = text
    else:
        raise HTTPException(400, "Provide a Dockerfile file or text.")
    if not any(l.strip().upper().startswith("FROM ") for l in t.splitlines()):
        raise HTTPException(422, "No FROM instruction found - this does not look like a Dockerfile.")
    ref = image_ref or (first_from_image(t) or "unnamed") + " (Dockerfile)"
    if len(ref) > 256:
        raise HTTPException(422, "Image reference too long.")
    parsed = {"image_ref": ref, "scanner": "stacksentinel-dockerfile-rules", "scanner_version": "1.0", "findings": analyse_dockerfile(t)}
    scan = create_scan(db, parsed, "dockerfile", False, t, notes="Static analysis only. No vulnerability scan was performed.")
    evaluate_scan(db, scan)
    return {"scan": sdict(scan), "findings": len(scan.findings)}


@router.post("/scans/live")
def live_scan(body: LiveScanIn, db: Session = Depends(get_db)):
    if not trivy_available():
        raise HTTPException(501, "Trivy is not installed on this server, so a live scan cannot run. Upload a Trivy JSON report instead.")
    try:
        parsed = run_live_scan(body.image_ref)
    except ParseError as e:
        raise HTTPException(422, str(e))
    except Exception as e:
        raise HTTPException(502, str(e)[:400])
    scan = create_scan(db, parsed, "trivy-live")
    evaluate_scan(db, scan)
    return {"scan": sdict(scan), "findings": len(scan.findings)}


@router.get("/scans")
def list_scans(db: Session = Depends(get_db), demo: bool | None = None, page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200)):
    q = select(Scan)
    if demo is not None:
        q = q.where(Scan.is_demo.is_(demo))
    total = db.scalar(select(func.count()).select_from(q.subquery()))
    rows = db.scalars(q.order_by(Scan.id.desc()).offset((page - 1) * page_size).limit(page_size))
    items = []
    for s in rows:
        d = latest_decision(db, s.id)
        fs = scan_findings(db, s.id)
        items.append(sdict(s) | {"decision": d.outcome if d else "NOT_EVALUATED", "findings": len(fs),
                                 "risk_score": risk_for(db, s.id, fs)["score"]})
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/scans/{scan_id}")
def get_scan(scan_id: int, db: Session = Depends(get_db)):
    s = _scan(db, scan_id)
    fs = scan_findings(db, s.id)
    d = latest_decision(db, s.id)
    return sdict(s) | {"dockerfile_text": s.dockerfile_text, "severity": {k: sum(f["severity"] == k for f in fs) for k in SEV},
                       "finding_count": len(fs), "decision": ddict(d) if d else None}


@router.get("/scans/{scan_id}/layers")
def layers(scan_id: int, db: Session = Depends(get_db)):
    s = _scan(db, scan_id)
    fs = scan_findings(db, s.id)
    vulns = [f for f in fs if f["kind"] == "vulnerability"]
    by: dict = {}
    for f in vulns:
        by.setdefault(f["layer_diff_id"], []).append(f)
    out = []
    for l in s.layers:
        items = by.pop(l["diff_id"], [])
        out.append(l | {"packages": sorted({f["pkg"] for f in items}),
                        "counts": {k: sum(f["severity"] == k for f in items) for k in SEV},
                        "fixable": sum(1 for f in items if f["fixed"]),
                        "findings": [{"id": f["id"], "ref_id": f["ref_id"], "pkg": f["pkg"], "severity": f["severity"], "fixed": f["fixed"]} for f in items],
                        "points": round(sum(finding_points(f)[0] for f in items), 2)})
    unattr = [f for items in by.values() for f in items]
    limits = ["Layer attribution comes only from the scanner's per-finding layer data; it shows where a package file lives, not who introduced it or why."]
    if not s.layers:
        limits.insert(0, "This scan contains no layer metadata (for example a Dockerfile-only analysis or a report without image metadata).")
    if unattr:
        limits.append(f"{len(unattr)} vulnerabilities carry no layer information and are shown as unattributed.")
    limits.append("Whether a vulnerable package could be fixed by a base-image change cannot be determined from scan data alone; fix versions are shown when the scanner reports them.")
    return {"scan": sdict(s), "layers": out, "unattributed": {"count": len(unattr), "findings": [{"id": f["id"], "ref_id": f["ref_id"], "pkg": f["pkg"], "severity": f["severity"]} for f in unattr[:100]]},
            "config_findings": [{"id": f["id"], "ref_id": f["ref_id"], "severity": f["severity"], "title": f["title"]} for f in fs if f["kind"] == "config"], "limitations": limits}


@router.get("/scans/{scan_id}/risk")
def risk(scan_id: int, db: Session = Depends(get_db)):
    _scan(db, scan_id)
    return risk_for(db, scan_id)


@router.get("/scans/{scan_id}/decisions")
def decisions(scan_id: int, db: Session = Depends(get_db)):
    _scan(db, scan_id)
    return [ddict(d) for d in db.scalars(select(Decision).where(Decision.scan_id == scan_id).order_by(Decision.id.desc()))]


@router.post("/scans/{scan_id}/evaluate")
def evaluate(scan_id: int, db: Session = Depends(get_db)):
    d = evaluate_scan(db, _scan(db, scan_id))
    return ddict(d)


# ---------- findings ----------
@router.get("/findings")
def findings(db: Session = Depends(get_db), scan_id: int | None = None, severity: str | None = None, kind: str | None = None,
             q: str | None = Query(None, max_length=100), fixable: bool | None = None, page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200)):
    st = select(Finding)
    if scan_id is not None:
        st = st.where(Finding.scan_id == scan_id)
    if severity:
        if severity.upper() not in SEV:
            raise HTTPException(422, "Unknown severity.")
        st = st.where(Finding.severity == severity.upper())
    if kind:
        if kind not in ("vulnerability", "config"):
            raise HTTPException(422, "kind must be vulnerability or config.")
        st = st.where(Finding.kind == kind)
    if fixable is True:
        st = st.where(Finding.fixed.is_not(None))
    if q:
        like = f"%{q}%"
        st = st.where(or_(Finding.ref_id.ilike(like), Finding.pkg.ilike(like), Finding.title.ilike(like)))
    total = db.scalar(select(func.count()).select_from(st.subquery()))
    sev_order = {s: i for i, s in enumerate(SEV)}
    rows = sorted(db.scalars(st), key=lambda f: (sev_order.get(f.severity, 9), f.id))[(page - 1) * page_size: page * page_size]
    vmap = {}
    items = []
    for f in rows:
        vmap.setdefault(f.scan_id, _verif(db, f.scan_id))
        items.append({k: v for k, v in fdict(f).items() if k not in ("description", "evidence", "resolution")} | {"verification": vmap[f.scan_id].get(f.id, "none")})
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/findings/{fid}")
def finding(fid: int, db: Session = Depends(get_db)):
    f = db.get(Finding, fid)
    if not f:
        raise HTTPException(404, "Finding not found.")
    s = db.get(Scan, f.scan_id)
    d = fdict(f)
    pts, notes = finding_points(d)
    rems = [{"id": r.id, "proposed_change": r.proposed_change, "status": r.status, "verified_by_scan_id": r.verified_by_scan_id, "created_at": r.created_at}
            for r in db.scalars(select(Remediation).where(Remediation.finding_id == fid).order_by(Remediation.id))]
    status = rems[-1]["status"] if rems else "none"
    return d | {"scan": sdict(s), "risk_points": pts, "risk_rationale": notes, "remediations": rems, "verification": status,
                "layer_note": None if f.layer_diff_id else "No layer information in the scan data for this finding."}


@router.post("/findings/{fid}/explain")
def explain(fid: int, db: Session = Depends(get_db)):
    f = db.get(Finding, fid)
    if not f:
        raise HTTPException(404, "Finding not found.")
    base = deterministic_explain(fdict(f))
    return llm_explain(fdict(f), base) or base


# ---------- policy ----------
@router.get("/policy")
def policy(db: Session = Depends(get_db)):
    p = get_policy(db)
    return {"id": p.id, "version": p.version, "name": p.name, "rules": p.rules, "created_at": p.created_at}


@router.put("/policy")
def set_policy(body: PolicyIn, db: Session = Depends(get_db)):
    try:
        rules = PolicyRules.model_validate(body.rules).model_dump()
    except Exception:
        raise HTTPException(422, "Invalid policy rules.")
    if any(not re.fullmatch(r"[A-Za-z0-9_.\-]{1,40}", r) for r in rules["prohibited_rules"]):
        raise HTTPException(422, "Rule IDs may contain only letters, digits, '.', '_' and '-'.")
    cur = get_policy(db)
    cur.active = False
    new = Policy(version=cur.version + 1, name=body.name or cur.name, rules=rules, active=True)
    db.add(new)
    db.commit()
    return {"id": new.id, "version": new.version, "name": new.name, "rules": new.rules, "created_at": new.created_at}


# ---------- remediation / compare ----------
@router.post("/remediations")
def add_remediation(body: RemediationIn, db: Session = Depends(get_db)):
    f = db.get(Finding, body.finding_id)
    if not f:
        raise HTTPException(404, "Finding not found.")
    r = Remediation(scan_id=f.scan_id, finding_id=f.id, finding_key=f.key, proposed_change=body.proposed_change)
    db.add(r)
    db.commit()
    return {"id": r.id, "status": r.status, "note": "Recorded as proposed. It is marked verified only after a later scan no longer contains this finding."}


@router.get("/remediations")
def list_rem(scan_id: int, db: Session = Depends(get_db)):
    return [{"id": r.id, "finding_id": r.finding_id, "finding_key": r.finding_key, "proposed_change": r.proposed_change, "status": r.status,
             "verified_by_scan_id": r.verified_by_scan_id, "created_at": r.created_at}
            for r in db.scalars(select(Remediation).where(Remediation.scan_id == scan_id).order_by(Remediation.id))]


def _compare(db: Session, before_id: int, after_id: int) -> dict:
    b, a = _scan(db, before_id), _scan(db, after_id)
    if b.id == a.id:
        raise HTTPException(422, "Choose two different scans.")
    bf, af = scan_findings(db, b.id), scan_findings(db, a.id)
    cmp = compare_findings(bf, af)
    res_keys = {f["key"] for f in cmp["resolved"]}
    rem_keys = {f["key"] for f in cmp["remaining"]}
    for r in db.scalars(select(Remediation).where(Remediation.scan_id == b.id)):
        if r.finding_key in res_keys:
            r.status, r.verified_by_scan_id = "verified", a.id
        elif r.finding_key in rem_keys and r.status != "verified":
            r.status, r.verified_by_scan_id = "not_resolved", a.id
    db.commit()
    return {"before": sdict(b), "after": sdict(a), "comparison": cmp, "before_risk": risk_for(db, b.id, bf), "after_risk": risk_for(db, a.id, af)}


@router.post("/compare")
def compare(body: CompareIn, db: Session = Depends(get_db)):
    out = _compare(db, body.before_scan_id, body.after_scan_id)
    bd = latest_decision(db, body.before_scan_id) or evaluate_scan(db, _scan(db, body.before_scan_id))
    ad = evaluate_scan(db, _scan(db, body.after_scan_id))  # re-evaluate under the current policy
    warn = None
    if out["before"]["image_ref"].rsplit(":", 1)[0] != out["after"]["image_ref"].rsplit(":", 1)[0]:
        warn = "These scans are for different image names; confirm they are two versions of the same artifact."
    return out | {"before_decision": ddict(bd), "after_decision": ddict(ad), "warning": warn}


# ---------- reports ----------
@router.post("/scans/{scan_id}/reports")
def make_report(scan_id: int, body: ReportIn, db: Session = Depends(get_db)):
    s = _scan(db, scan_id)
    fs = scan_findings(db, s.id)
    d = latest_decision(db, s.id) or evaluate_scan(db, s)
    rk = risk_for(db, s.id, fs)
    if body.kind == "receipt":
        content, fn = build_receipt(sdict(s), ddict(d), rk, fs), f"decision-receipt-scan{s.id}.json"
    else:
        cmp = None
        if body.compare_with_scan_id:
            cmp = _compare(db, s.id, body.compare_with_scan_id)["comparison"]
        rems = [{"finding_id": r.finding_id, "proposed_change": r.proposed_change, "status": r.status} for r in db.scalars(select(Remediation).where(Remediation.scan_id == s.id))]
        content, fn = build_report(sdict(s), fs, rk, ddict(d), rems, cmp), f"evidence-report-scan{s.id}.md"
    rep = Report(scan_id=s.id, kind=body.kind, filename=fn, sha256=sha256_text(content), content=content, is_demo=s.is_demo)
    db.add(rep)
    db.commit()
    return {"id": rep.id, "kind": rep.kind, "filename": fn, "sha256": rep.sha256, "is_demo": rep.is_demo, "created_at": rep.created_at, "preview": content[:3000]}


@router.get("/scans/{scan_id}/reports")
def list_reports(scan_id: int, db: Session = Depends(get_db)):
    return [{"id": r.id, "kind": r.kind, "filename": r.filename, "sha256": r.sha256, "is_demo": r.is_demo, "created_at": r.created_at}
            for r in db.scalars(select(Report).where(Report.scan_id == scan_id).order_by(Report.id.desc()))]


@router.get("/reports/{rid}/download")
def download(rid: int, db: Session = Depends(get_db)):
    r = db.get(Report, rid)
    if not r:
        raise HTTPException(404, "Report not found.")
    mt = "application/json" if r.kind == "receipt" else "text/markdown"
    return Response(r.content.encode("utf-8"), media_type=mt, headers={"Content-Disposition": f'attachment; filename="{r.filename}"', "X-Content-SHA256": r.sha256})


@router.post("/reports/verify")
async def verify(file: UploadFile = File(...), db: Session = Depends(get_db)):
    data = await _read(file, 2 * 1024 * 1024)
    import hashlib
    h = hashlib.sha256(data).hexdigest()
    r = db.scalar(select(Report).where(Report.sha256 == h))
    note = "Integrity check only: confirms the file matches a report this platform generated. It does not prove the scanner results were authentic."
    if r:
        return {"valid": True, "sha256": h, "report_id": r.id, "kind": r.kind, "scan_id": r.scan_id, "generated_at": r.created_at, "note": note}
    return {"valid": False, "sha256": h, "note": "No report generated by this platform matches this file's hash. The file was modified or came from elsewhere."}
