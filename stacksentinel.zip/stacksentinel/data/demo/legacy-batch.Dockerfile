FROM debian:latest
ENV DB_PASSWORD=changeme123
ADD https://example.invalid/tool.tar.gz /opt/
RUN apt-get update && apt-get install -y curl
RUN curl -sSL https://example.invalid/install.sh | sh
RUN chmod -R 777 /opt/batch
EXPOSE 22
COPY batch /opt/batch
CMD ["/opt/batch/run.sh"]
