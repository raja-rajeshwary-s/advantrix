import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]          # repo root
BACKEND = ROOT / "backend"

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BACKEND / 'stacksentinel.db'}")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(10 * 1024 * 1024)))
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,http://localhost:8000").split(",") if o.strip()]
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-4-6")
TRIVY_TIMEOUT = int(os.getenv("TRIVY_TIMEOUT", "600"))
DEMO_DIR = ROOT / "data" / "demo"
FRONTEND_DIST = ROOT / "frontend" / "dist"
SEED_DEMO = os.getenv("SEED_DEMO", "1") == "1"
