import json, os, tempfile
os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"
from fastapi.testclient import TestClient
from app.main import app
from app.policies.engine import evaluate
from app.risk.engine import compute_risk
from app.scanners.dockerfile import analyse_dockerfile
from app.scanners.trivy import ParseError, parse_trivy_report
from app.services.compare import compare_findings
import pytest


def F(i, sev="HIGH", fixed="1.1", kind="vulnerability", ref="V-1", cvss=None):
    return {"id": i, "key": f"{ref}|p{i}", "kind": kind, "severity": sev, "fixed": fixed, "ref_id": ref, "pkg": f"p{i}", "cvss": cvss, "cvss_source": "nvd" if cvss else None, "exploit_known": None}


def test_risk_deterministic_and_explained():
    fs = [F(1, "CRITICAL", cvss=9.8), F(2, "LOW")]
    a, b = compute_risk(fs), compute_risk(list(reversed(fs)))
    assert a["score"] == b["score"] and a["classification"] in ("High", "Critical")
    assert a["top_contributors"][0]["finding_id"] == 1
    assert any("Exploit evidence" in m for m in a["missing_information"])  # nothing invented
    assert compute_risk([])["classification"] == "Clean"


def test_policy_enforcement():
    rules = {"block_critical": True, "block_high_with_fix": False, "block_root": True}
    assert evaluate(rules, [F(1, "CRITICAL")], 50)["outcome"] == "BLOCKED"
    assert evaluate(rules, [F(1, "HIGH")], 50)["outcome"] == "APPROVED"
    assert evaluate({**rules, "block_high_with_fix": True}, [F(1, "HIGH")], 50)["outcome"] == "BLOCKED"
    assert evaluate(rules, [F(1, "HIGH", None, "config", "SS-DF-002")], 10)["violations"][0]["rule"] == "block_root"


def test_trivy_parse_and_reject():
    rep = {"ArtifactName": "x:1", "Results": [{"Target": "t", "Vulnerabilities": [
        {"VulnerabilityID": "A-1", "PkgName": "p", "InstalledVersion": "1", "FixedVersion": "2", "Severity": "high", "CVSS": {"nvd": {"V3Score": 7.5}}}]}]}
    p = parse_trivy_report(json.dumps(rep))
    assert p["findings"][0]["severity"] == "HIGH" and p["findings"][0]["cvss"] == 7.5 and p["findings"][0]["layer_diff_id"] is None
    for bad in ("not json", "[]", '{"foo":1}', '{"ArtifactName":"x","Results":[{"Vulnerabilities":[{"PkgName":"p"}]}]}'):
        with pytest.raises(ParseError):
            parse_trivy_report(bad)


def test_dockerfile_rules():
    ids = {f["ref_id"] for f in analyse_dockerfile("FROM node:latest\nRUN curl x | sh\nUSER app\n")}
    assert {"SS-DF-001", "SS-DF-004", "SS-DF-007"} <= ids and "SS-DF-002" not in ids


def test_compare():
    c = compare_findings([F(1, ref="A"), F(2, ref="B")], [{**F(3, ref="B"), "key": "B|p2"}, F(4, ref="C")])
    assert c["counts"] == {"before": 2, "after": 2, "resolved": 1, "remaining": 1, "introduced": 1}


def test_end_to_end_api():
    with TestClient(app) as c:
        ov = c.get("/api/overview").json()
        assert ov["images"]["demo"] == 5 and ov["images"]["live"] == 0
        scans = {s["image_ref"]: s for s in c.get("/api/scans").json()["items"]}
        blocked, fixed = scans["demo/payments-svc:0.9.0"], scans["demo/payments-svc:0.9.1"]
        assert blocked["decision"] == "BLOCKED" and fixed["decision"] == "APPROVED"
        cmp = c.post("/api/compare", json={"before_scan_id": blocked["id"], "after_scan_id": fixed["id"]}).json()
        assert cmp["comparison"]["counts"]["resolved"] == 3 and cmp["comparison"]["counts"]["introduced"] == 1
        # remediation is verified only by the comparison, never by recording it
        f = c.get(f"/api/findings?scan_id={blocked['id']}&severity=HIGH").json()["items"][0]
        r = c.post("/api/remediations", json={"finding_id": f["id"], "proposed_change": "upgrade pkg"}).json()
        assert r["status"] == "proposed"
        assert c.get(f"/api/findings/{f['id']}").json()["verification"] == "proposed"
        # policy change is enforced by the backend
        scan_id = scans["demo/web-frontend:2.1.0"]["id"]
        assert c.post(f"/api/scans/{scan_id}/evaluate").json()["outcome"] == "APPROVED"
        pol = c.get("/api/policy").json()["rules"]
        c.put("/api/policy", json={"rules": {**pol, "block_high_with_fix": True}})
        assert c.post(f"/api/scans/{scan_id}/evaluate").json()["outcome"] == "BLOCKED"
        # report integrity
        rep = c.post(f"/api/scans/{scan_id}/reports", json={"kind": "report"}).json()
        body = c.get(f"/api/reports/{rep['id']}/download").content
        assert c.post("/api/reports/verify", files={"file": ("r.md", body)}).json()["valid"] is True
        assert c.post("/api/reports/verify", files={"file": ("r.md", body + b"x")}).json()["valid"] is False
        # safe rejection of bad uploads
        assert c.post("/api/scans/trivy-report", files={"file": ("a.json", b"nope")}).status_code == 422
        assert c.post("/api/scans/trivy-report", files={"file": ("a.txt", b"{}")}).status_code == 400
        assert c.post("/api/scans/dockerfile", data={"text": "hello"}).status_code == 422
        assert c.post("/api/scans/live", json={"image_ref": "x"}).status_code in (501, 502)
        assert c.get("/api/findings?severity=BAD").status_code == 422
