"""Remediation assistant. Evidence-grounded; deterministic engine always available, LLM optional."""
import httpx
from ..core import config

HINTS = {
    "SS-DF-001": "Pin FROM to an exact version (and digest). Test the new base in CI because minor-version bumps can change libc/openssl behaviour.",
    "SS-DF-002": "Add a non-root user (e.g. `RUN adduser -D app` then `USER app`). Check that the app can write only to the directories it needs.",
    "SS-DF-003": "Replace ADD with COPY for local files.",
    "SS-DF-004": "Download the script to a file, verify a pinned checksum, then run it.",
    "SS-DF-005": "Remove the value from the image; inject it at runtime or with a BuildKit secret mount. Rotate any value already committed.",
    "SS-DF-006": "Use `apt-get install --no-install-recommends` and delete /var/lib/apt/lists in the same RUN.",
    "SS-DF-007": "Add a HEALTHCHECK that calls a lightweight endpoint.",
    "SS-DF-008": "Replace chmod 777 with the least-privilege mode.",
    "SS-DF-009": "Remove EXPOSE 22 and any SSH daemon.",
}


def deterministic_explain(f: dict) -> dict:
    facts, suggestions, unc = [], [], []
    if f["kind"] == "vulnerability":
        facts.append(f"{f['ref_id']} affects package {f['pkg']} {f['installed']} (scanner severity {f['severity']}).")
        if f.get("cvss") is not None:
            facts.append(f"Scanner CVSS: {f['cvss']} (source {f.get('cvss_source')}).")
        if f.get("fixed"):
            facts.append(f"Scanner lists fixed version(s): {f['fixed']}.")
            suggestions.append(f"Upgrade {f['pkg']} to {f['fixed'].split(',')[0].strip()} or newer, e.g. by rebuilding on a base image that ships it. Then re-scan to verify.")
            unc.append("Compatibility with your application was not tested; run your test suite after the upgrade.")
        else:
            suggestions.append("No fixed version is reported. Consider a different base image, removing the package if unused, or documenting an accepted risk.")
        unc.append("Whether your application actually calls the vulnerable code path is not known from scan data.")
        unc.append("No exploit-availability data was supplied, so none is assumed.")
    else:
        facts.append(f"Rule {f['ref_id']}: {f['title']} (severity {f['severity']}).")
        if (f.get("evidence") or {}).get("snippet"):
            facts.append(f"Evidence, line {f['evidence'].get('line')}: `{f['evidence']['snippet']}`")
        suggestions.append(HINTS.get(f["ref_id"], f.get("resolution") or "See the rule's resolution guidance."))
        unc.append("Static analysis only; the configuration was not executed.")
    return {"mode": "deterministic-rules", "finding_id": f["id"], "facts": facts, "suggestions": suggestions,
            "uncertainty": unc, "verified": False,
            "note": "Suggestions are not verified. A fix counts as resolved only after a new scan no longer contains the finding."}


def llm_explain(f: dict, base: dict) -> dict | None:
    if not config.ANTHROPIC_API_KEY:
        return None
    prompt = ("You are a container security assistant. Using ONLY the evidence below, explain the issue in plain English "
              "(max 120 words), then give remediation steps. Mark anything not in the evidence as uncertain. Do not claim a fix is verified.\n\nEVIDENCE:\n"
              + "\n".join(base["facts"]) + f"\nTitle: {f['title']}\nDescription: {f['description'][:600]}")
    try:
        r = httpx.post("https://api.anthropic.com/v1/messages", timeout=30,
                       headers={"x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                       json={"model": config.LLM_MODEL, "max_tokens": 500, "messages": [{"role": "user", "content": prompt}]})
        r.raise_for_status()
        text = "".join(b.get("text", "") for b in r.json().get("content", []))
        return base | {"mode": f"llm:{config.LLM_MODEL}", "narrative": text}
    except Exception:
        return None  # fall back silently to deterministic output
