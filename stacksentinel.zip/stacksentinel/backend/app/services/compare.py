def compare_findings(before: list[dict], after: list[dict]) -> dict:
    b = {f["key"]: f for f in before}
    a = {f["key"]: f for f in after}
    brief = lambda f: {k: f.get(k) for k in ("id", "key", "kind", "ref_id", "pkg", "installed", "fixed", "severity", "title")}
    resolved = [brief(b[k]) for k in b if k not in a]
    remaining = [brief(a[k]) | {"before_id": b[k]["id"]} for k in a if k in b]
    introduced = [brief(a[k]) for k in a if k not in b]
    return {"resolved": resolved, "remaining": remaining, "introduced": introduced,
            "counts": {"before": len(b), "after": len(a), "resolved": len(resolved), "remaining": len(remaining), "introduced": len(introduced)}}
