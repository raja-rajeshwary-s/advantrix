# StackSentinel - Container Trust & Intelligence Platform
*Every layer has a story. Every deployment must earn trust.*

Hackathon prototype for **Cloud - Secure Container Delivery**: analyse container images, explain risk, enforce a policy gate in the backend, verify fixes with a second scan, and export tamper-evident evidence.

## Run it (one command, no Node needed)
Requires Python 3.10+.
```bash
./scripts/start.sh        # Windows: scripts\start.bat
# open http://localhost:8000
```
The UI is prebuilt in `frontend/dist` and served by the API. It works offline with no Docker, Trivy, PostgreSQL or LLM key.

Developer mode: `cd backend && uvicorn app.main:app --reload` and `cd frontend && npm install && npm run dev` (http://localhost:5173, proxies `/api`).

## What is real vs demo
| Item | Status |
|---|---|
| 5 seeded images | **Synthetic**, labelled DEMO DATA. IDs use the `DEMO-VULN-####` namespace so no real CVE is misrepresented. They go through the real parser. |
| Trivy JSON import | Real parser, schema-validated |
| Live image scan | Real, only if `trivy` is on the server PATH (otherwise the UI says so; nothing is faked) |
| Dockerfile analysis | Real static rules (9); the file is never built or run |
| Risk score | Deterministic rules model `rules-1.0`; no ML |
| Policy gate | Enforced in the backend; each evaluation stores policy snapshot + record hash |
| Assistant | Deterministic explainer; uses an LLM only if `ANTHROPIC_API_KEY` is set (server-side) |
| Evidence | Markdown report + JSON receipt, SHA-256 verified on re-upload |

## Differentiators
Evidence-linked risk, Trust Gate, Fix-to-Verify (a remediation is `verified` only when a later scan lacks the finding), Layer Intelligence with stated limits, Decision Receipt, scan-integrity hashing.

## API (prefix `/api`, interactive docs at `/docs`)
GET `health, capabilities, overview, scans, scans/{id}, scans/{id}/layers|risk|decisions|reports, findings, findings/{id}, policy, remediations, reports/{id}/download`
POST `scans/trivy-report, scans/dockerfile, scans/live, scans/{id}/evaluate, scans/{id}/reports, findings/{id}/explain, remediations, compare, reports/verify` - PUT `policy`

## Tests
```bash
cd backend && pip install -r requirements.txt && python -m pytest -q
cd frontend && npm install && npm run build
```
Docs: `docs/architecture.md` (diagrams), `docs/DEMO_SCRIPT.md`. CI: `.github/workflows/ci.yml`.

## Security notes
Upload size/type limits; Trivy invoked without a shell using a validated image reference; no user input reaches the filesystem; generic 500 errors; keys only from environment.

## Known limitations
No authentication (single-user prototype; add before exposing it). Hadolint, Grype and Cosign are not integrated (Cosign is only detected). Exploit/EPSS data is not ingested, so it is reported as unknown. The live-scan path is implemented but was not exercised here because Trivy was not installed in the build environment. Demo timestamps are fixed fixtures.
