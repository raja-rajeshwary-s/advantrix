@echo off
cd /d "%~dp0\..\backend"
if not exist .venv python -m venv .venv
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
echo StackSentinel running on http://localhost:8000
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
