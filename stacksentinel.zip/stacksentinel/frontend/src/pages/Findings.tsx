import { useState } from "react";
import { get, useAsync } from "../services/api";
import { Card, DemoTag, Empty, Err, Loading, Mono, PageHead, SevBadge, SEVS } from "../components/ui";
import { useApp } from "../components/Shell";

const VCOL: Record<string, string> = { none: "text-mute", proposed: "text-amber", verified: "text-lime", not_resolved: "text-crit" };

export default function Findings() {
  const { scanId, scan, openFinding } = useApp();
  const [q, setQ] = useState(""); const [sev, setSev] = useState(""); const [kind, setKind] = useState(""); const [fix, setFix] = useState(false); const [page, setPage] = useState(1);
  const qs = new URLSearchParams({ scan_id: String(scanId ?? ""), page: String(page), page_size: "25" });
  if (q) qs.set("q", q); if (sev) qs.set("severity", sev); if (kind) qs.set("kind", kind); if (fix) qs.set("fixable", "true");
  const r = useAsync(() => (scanId ? get(`/findings?${qs}`) : Promise.resolve(null)), [scanId, q, sev, kind, fix, page]);
  const reset = (f: () => void) => { f(); setPage(1); };
  const d = r.data;
  return (<>
    <PageHead title="Finding intelligence" sub={scan ? `Findings for ${scan.image_ref}. Select a row to open the inspector.` : ""} right={scan?.is_demo ? <DemoTag /> : undefined} />
    <div className="mb-3 flex flex-wrap items-end gap-3 text-[13px]">
      <label className="text-mute">Search<input value={q} onChange={(e) => reset(() => setQ(e.target.value))} placeholder="CVE, package, title" className="mt-1 block w-56 border border-line bg-graphite p-1.5 text-ivory" /></label>
      <label className="text-mute">Severity<select value={sev} onChange={(e) => reset(() => setSev(e.target.value))} className="mt-1 block border border-line bg-graphite p-1.5 text-ivory"><option value="">All</option>{SEVS.map((s) => <option key={s}>{s}</option>)}</select></label>
      <label className="text-mute">Type<select value={kind} onChange={(e) => reset(() => setKind(e.target.value))} className="mt-1 block border border-line bg-graphite p-1.5 text-ivory"><option value="">All</option><option value="vulnerability">Vulnerabilities</option><option value="config">Configuration</option></select></label>
      <label className="flex items-center gap-2 pb-2 text-mute"><input type="checkbox" checked={fix} onChange={(e) => reset(() => setFix(e.target.checked))} />Fix available</label>
    </div>
    <Err msg={r.error} />{r.loading && !d && <Loading />}
    {d && (d.items.length === 0 ? <Empty>No findings match these filters.</Empty> : (<Card><div className="overflow-x-auto"><table className="w-full text-left text-[13px]">
      <thead className="text-mute"><tr className="border-b border-line"><th className="py-1.5">Severity</th><th>ID</th><th>Package / location</th><th>Installed</th><th>Fixed</th><th>CVSS</th><th>Verification</th></tr></thead>
      <tbody>{d.items.map((f: any) => (<tr key={f.id} tabIndex={0} onClick={() => openFinding(f.id)} onKeyDown={(e) => e.key === "Enter" && openFinding(f.id)} className="cursor-pointer border-b border-line/60 hover:bg-panel">
        <td className="py-2"><SevBadge s={f.severity} /></td><td><Mono>{f.ref_id}</Mono></td><td><Mono>{f.pkg ?? f.title}</Mono></td><td><Mono>{f.installed ?? "-"}</Mono></td>
        <td><Mono className={f.fixed ? "text-lime" : "text-mute"}>{f.fixed ?? "none"}</Mono></td><td><Mono>{f.cvss ?? "n/a"}</Mono></td><td><Mono className={VCOL[f.verification]}>{f.verification}</Mono></td></tr>))}</tbody></table></div>
      <div className="mt-3 flex items-center justify-between text-[12px] text-mute"><span>{d.total} findings - page {d.page}</span>
        <span className="space-x-2"><button disabled={page <= 1} onClick={() => setPage(page - 1)} className="border border-line px-2 py-1 disabled:opacity-40">Previous</button><button disabled={page * 25 >= d.total} onClick={() => setPage(page + 1)} className="border border-line px-2 py-1 disabled:opacity-40">Next</button></span></div></Card>))}
  </>);
}
