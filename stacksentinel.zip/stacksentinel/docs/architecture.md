# Architecture and workflow

```mermaid
flowchart LR
  subgraph UI[React + Vite + Tailwind]
    P[Overview / Inspect / Layers / Findings / Risk / Policy / Fix-to-Verify / Evidence]
  end
  subgraph API[FastAPI]
    R[REST routes] --> S[Scanners: Trivy parser, live Trivy runner, Dockerfile rules]
    R --> K[Risk engine rules-1.0]
    R --> G[Policy gate]
    R --> A[Assistant: rules + optional LLM]
    R --> E[Reports and receipts SHA-256]
  end
  P -->|/api| R
  S & K & G & E --> DB[(SQLite / PostgreSQL)]
  A -.optional, server-side key.-> LLM[(LLM API)]
  S -.optional.-> T[Trivy binary]
```

```mermaid
flowchart TD
  A[Import Trivy JSON / Dockerfile / live scan] --> B[Validate + parse + store findings]
  B --> C[Risk score with factor breakdown]
  C --> D{Policy gate - backend}
  D -->|violations| X[BLOCKED + decision record]
  D -->|none| Y[APPROVED + decision record]
  X --> F[Record remediation: status = proposed]
  F --> G[Import new scan]
  G --> H[Compare: resolved / remaining / new]
  H --> I[Remediation becomes verified only if finding is gone]
  I --> D
  Y --> J[Evidence report + decision receipt with SHA-256]
  X --> J
```

## Honest scope
- Risk model is rule-based. No ML model is trained or claimed.
- SHA-256 proves a report was not modified after export; it does not prove scanner authenticity. Receipts are hashed, not signed.
- Cosign is detected in capabilities but signing/verification is not implemented.
- Layer attribution uses only the scanner's per-finding layer data.
