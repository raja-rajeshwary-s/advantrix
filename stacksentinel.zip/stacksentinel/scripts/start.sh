#!/usr/bin/env bash
# One-command start: installs backend deps and serves API + prebuilt UI on http://localhost:8000
set -e
cd "$(dirname "$0")/../backend"
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r requirements.txt
echo "StackSentinel running on http://localhost:8000"
exec python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
