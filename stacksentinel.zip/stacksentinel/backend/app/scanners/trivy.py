"""Trivy JSON report parsing (schema-validated) and optional live scan via safe subprocess."""
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from ..core.config import TRIVY_TIMEOUT

SEVERITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"]
IMAGE_REF_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._\-/:@]{0,255}$")


class ParseError(ValueError):
    pass


class _Layer(BaseModel):
    model_config = ConfigDict(extra="ignore")
    DiffID: Optional[str] = None
    Digest: Optional[str] = None


class _Vuln(BaseModel):
    model_config = ConfigDict(extra="ignore")
    VulnerabilityID: str
    PkgName: str
    InstalledVersion: Optional[str] = None
    FixedVersion: Optional[str] = None
    Severity: str = "UNKNOWN"
    Title: Optional[str] = None
    Description: Optional[str] = None
    PrimaryURL: Optional[str] = None
    CVSS: Optional[dict[str, Any]] = None
    Layer: Optional[_Layer] = None
    ExploitKnown: Optional[bool] = None  # not a Trivy field; honoured only if a pipeline supplies it


class _Misconf(BaseModel):
    model_config = ConfigDict(extra="ignore")
    ID: str
    Title: Optional[str] = None
    Description: Optional[str] = None
    Message: Optional[str] = None
    Resolution: Optional[str] = None
    Severity: str = "UNKNOWN"
    PrimaryURL: Optional[str] = None


class _Result(BaseModel):
    model_config = ConfigDict(extra="ignore")
    Target: str = ""
    Class: Optional[str] = None
    Type: Optional[str] = None
    Vulnerabilities: Optional[list[_Vuln]] = None
    Misconfigurations: Optional[list[_Misconf]] = None


class _Report(BaseModel):
    model_config = ConfigDict(extra="ignore")
    SchemaVersion: Optional[int] = None
    ArtifactName: Optional[str] = None
    ArtifactType: Optional[str] = None
    CreatedAt: Optional[str] = None
    Metadata: Optional[dict[str, Any]] = None
    Results: list[_Result] = Field(default_factory=list)
    TrivyVersion: Optional[str] = None


def _best_cvss(cvss: Optional[dict]) -> tuple[Optional[float], Optional[str]]:
    if not cvss:
        return None, None
    for src in ("nvd", "redhat", "ghsa", *cvss.keys()):
        d = cvss.get(src)
        if isinstance(d, dict):
            for k in ("V3Score", "V2Score"):
                if isinstance(d.get(k), (int, float)):
                    return float(d[k]), src
    return None, None


def _norm_sev(s: str) -> str:
    s = (s or "UNKNOWN").upper()
    return s if s in SEVERITIES else "UNKNOWN"


def parse_trivy_report(raw: bytes | str) -> dict:
    """Return a normalised dict: scan metadata + findings. Raises ParseError on invalid input."""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise ParseError("File is not valid JSON.") from e
    if not isinstance(data, dict) or "Results" not in data and "ArtifactName" not in data:
        raise ParseError("JSON does not look like a Trivy report (expected 'ArtifactName' / 'Results').")
    try:
        rep = _Report.model_validate(data)
    except ValidationError as e:
        raise ParseError(f"Trivy report failed schema validation: {e.errors()[0]['loc']} {e.errors()[0]['msg']}") from e

    meta = rep.Metadata or {}
    diff_ids = meta.get("DiffIDs") or []
    history = [h for h in ((meta.get("ImageConfig") or {}).get("history") or []) if not h.get("empty_layer")]
    layers = []
    for i, d in enumerate(diff_ids):
        cb = history[i].get("created_by") if i < len(history) else None
        layers.append({"index": i, "diff_id": d, "created_by": cb})

    digests = meta.get("RepoDigests") or []
    digest = digests[0].split("@")[-1] if digests else None
    os_meta = meta.get("OS") or {}
    scanned_at = None
    if rep.CreatedAt:
        try:
            scanned_at = datetime.fromisoformat(rep.CreatedAt.replace("Z", "+00:00"))
        except ValueError:
            scanned_at = None

    findings: list[dict] = []
    for res in rep.Results:
        for v in res.Vulnerabilities or []:
            score, src = _best_cvss(v.CVSS)
            findings.append({
                "key": f"{v.VulnerabilityID}|{v.PkgName}", "kind": "vulnerability",
                "ref_id": v.VulnerabilityID, "pkg": v.PkgName, "installed": v.InstalledVersion,
                "fixed": v.FixedVersion or None, "severity": _norm_sev(v.Severity),
                "cvss": score, "cvss_source": src, "exploit_known": v.ExploitKnown,
                "title": v.Title or v.VulnerabilityID, "description": v.Description or "",
                "target": res.Target, "layer_diff_id": v.Layer.DiffID if v.Layer else None,
                "evidence": {"source": "trivy-report", "url": v.PrimaryURL, "target": res.Target,
                             "layer_digest": v.Layer.Digest if v.Layer else None},
                "resolution": None,
            })
        for m in res.Misconfigurations or []:
            findings.append({
                "key": f"{m.ID}|{res.Target}", "kind": "config", "ref_id": m.ID, "pkg": None,
                "installed": None, "fixed": None, "severity": _norm_sev(m.Severity), "cvss": None,
                "cvss_source": None, "exploit_known": None, "title": m.Title or m.ID,
                "description": m.Description or m.Message or "", "target": res.Target,
                "layer_diff_id": None,
                "evidence": {"source": "trivy-misconfig", "url": m.PrimaryURL, "target": res.Target},
                "resolution": m.Resolution,
            })
    return {
        "image_ref": rep.ArtifactName or "unknown-artifact", "digest": digest,
        "scanner": "trivy", "scanner_version": rep.TrivyVersion or (data.get("Trivy") or {}).get("Version"),
        "scanned_at": scanned_at or datetime.now(timezone.utc),
        "os_family": os_meta.get("Family"), "layers": layers, "findings": findings,
    }


def trivy_available() -> Optional[str]:
    return shutil.which("trivy")


def run_live_scan(image_ref: str) -> dict:
    """Run a real Trivy scan. Never uses a shell; image_ref is validated; nothing is executed from the image."""
    if not IMAGE_REF_RE.match(image_ref) or image_ref.startswith("-"):
        raise ParseError("Invalid image reference.")
    exe = trivy_available()
    if not exe:
        raise RuntimeError("Trivy is not installed on this server.")
    proc = subprocess.run(
        [exe, "image", "--format", "json", "--quiet", "--scanners", "vuln,misconfig", image_ref],
        capture_output=True, timeout=TRIVY_TIMEOUT, shell=False, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError("Trivy scan failed: " + proc.stderr.decode("utf-8", "replace")[-300:])
    return parse_trivy_report(proc.stdout)
