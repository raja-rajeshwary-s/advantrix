"""Static Dockerfile analysis. The file is only read as text - never built or executed."""
import re

RULES = {
    "SS-DF-001": ("MEDIUM", "Base image uses 'latest' or no tag",
                  "Unpinned base images change silently, so scan results cannot be reproduced.",
                  "Pin the base image to a specific version, ideally by digest (FROM image:1.2.3@sha256:...)."),
    "SS-DF-002": ("HIGH", "Container runs as root",
                  "No non-root USER is set, so the process runs as root inside the container.",
                  "Create an unprivileged user and add 'USER appuser' before the entrypoint."),
    "SS-DF-003": ("LOW", "ADD used where COPY would do",
                  "ADD has extra behaviour (archive extraction, remote fetch) that is rarely needed.",
                  "Use COPY for local files."),
    "SS-DF-004": ("CRITICAL", "Remote script piped into a shell",
                  "Downloading and executing a script in one step runs unverified code at build time.",
                  "Download to a file, verify its checksum or signature, then execute it."),
    "SS-DF-005": ("HIGH", "Possible secret stored in ENV/ARG",
                  "Values set with ENV/ARG are readable in image history.",
                  "Inject secrets at runtime (orchestrator secrets) or use BuildKit secret mounts."),
    "SS-DF-006": ("LOW", "apt-get install without --no-install-recommends",
                  "Pulls in extra packages, enlarging the attack surface.",
                  "Add --no-install-recommends and clean the apt lists in the same layer."),
    "SS-DF-007": ("LOW", "No HEALTHCHECK defined",
                  "Without a health check the platform cannot detect a hung container.",
                  "Add a HEALTHCHECK instruction."),
    "SS-DF-008": ("MEDIUM", "World-writable permissions (chmod 777)",
                  "Any process in the container can modify these files.",
                  "Grant the minimum required mode, for example 755 or 644."),
    "SS-DF-009": ("MEDIUM", "SSH port exposed",
                  "Exposing port 22 suggests an SSH daemon runs in the container.",
                  "Remove EXPOSE 22 and use 'docker exec' / kubectl exec for access."),
}
SECRET_RE = re.compile(r"(PASSWORD|PASSWD|SECRET|TOKEN|API[_-]?KEY|PRIVATE[_-]?KEY)", re.I)
ROOT_USERS = {"root", "0", "0:0", "root:root"}


def _logical_lines(text: str):
    buf, start = "", 0
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.rstrip()
        if not buf:
            start = i
        if line.strip().startswith("#") and not buf:
            continue
        if line.endswith("\\"):
            buf += line[:-1] + " "
            continue
        buf += line
        if buf.strip():
            yield start, buf.strip()
        buf = ""
    if buf.strip():
        yield start, buf.strip()


def analyse_dockerfile(text: str, target: str = "Dockerfile") -> list[dict]:
    out: list[dict] = []

    def add(rule, line, snippet, extra=""):
        sev, title, desc, fix = RULES[rule]
        out.append({
            "key": f"{rule}|{snippet.strip()[:80]}", "kind": "config", "ref_id": rule, "pkg": None,
            "installed": None, "fixed": None, "severity": sev, "cvss": None, "cvss_source": None,
            "exploit_known": None, "title": title, "description": (desc + " " + extra).strip(),
            "target": target, "layer_diff_id": None,
            "evidence": {"source": "stacksentinel-dockerfile-rules", "line": line, "snippet": snippet.strip()[:200], "target": target},
            "resolution": fix,
        })

    last_user, has_health, last_from_line, stages = None, False, 0, []
    for ln, line in _logical_lines(text):
        parts = line.split(None, 1)
        ins, arg = parts[0].upper(), (parts[1] if len(parts) > 1 else "")
        if ins == "FROM":
            toks = [t for t in arg.split() if not t.startswith("--")]
            img = toks[0] if toks else ""
            stages.append(toks[-1] if len(toks) >= 3 and toks[-2].upper() == "AS" else None)
            last_user, last_from_line = None, ln
            if img.lower() != "scratch" and img not in stages[:-1]:
                name_tag = img.split("@")[0]
                tag = name_tag.rsplit(":", 1)[1] if ":" in name_tag.rsplit("/", 1)[-1] else None
                if "@sha256:" not in img and (tag is None or tag == "latest"):
                    add("SS-DF-001", ln, line)
        elif ins == "USER":
            last_user = arg.split()[0].lower() if arg else None
        elif ins == "HEALTHCHECK" and not arg.upper().startswith("NONE"):
            has_health = True
        elif ins == "ADD":
            add("SS-DF-003", ln, line)
        elif ins in ("ENV", "ARG"):
            m = re.match(r"([A-Za-z0-9_]+)(?:[= ]+(.+))?", arg)
            if m and SECRET_RE.search(m.group(1)) and m.group(2):
                add("SS-DF-005", ln, f"{ins} {m.group(1)}=<redacted>")
        elif ins == "EXPOSE" and re.search(r"(^|\s)22(/tcp)?(\s|$)", arg):
            add("SS-DF-009", ln, line)
        if ins == "RUN":
            if re.search(r"(curl|wget)\b[^|;&]*\|\s*(sudo\s+)?(ba|z)?sh\b", arg):
                add("SS-DF-004", ln, line)
            if re.search(r"chmod\s+(-R\s+)?0?777", arg):
                add("SS-DF-008", ln, line)
            if "apt-get install" in arg and "--no-install-recommends" not in arg:
                add("SS-DF-006", ln, line)
    if stages:
        if last_user is None or last_user in ROOT_USERS:
            add("SS-DF-002", last_from_line, "USER root (explicit)" if last_user else "no USER instruction in final stage")
        if not has_health:
            add("SS-DF-007", 0, "no HEALTHCHECK instruction")
    return out


def first_from_image(text: str) -> str | None:
    for _, line in _logical_lines(text):
        if line.upper().startswith("FROM "):
            toks = [t for t in line.split()[1:] if not t.startswith("--")]
            if toks:
                return toks[0]
    return None
