"""Backend-enforced security policy gate."""
import hashlib
import json
from typing import Optional
from pydantic import BaseModel, Field

ROOT_RULES = {"SS-DF-002", "DS002", "AVD-DS-0002"}


class PolicyRules(BaseModel):
    block_critical: bool = True
    block_high_with_fix: bool = False
    max_high: Optional[int] = Field(default=None, ge=0, le=100000)
    block_root: bool = True
    prohibited_rules: list[str] = Field(default_factory=list, max_length=50)
    max_risk_score: Optional[float] = Field(default=None, ge=0, le=100)


def evaluate(rules: dict, findings: list[dict], risk_score: float) -> dict:
    r = PolicyRules.model_validate(rules)
    v: list[dict] = []

    def viol(rule, msg, fs):
        v.append({"rule": rule, "message": msg, "finding_ids": [f["id"] for f in fs],
                  "findings": [{"id": f["id"], "ref_id": f["ref_id"], "pkg": f.get("pkg"), "severity": f["severity"]} for f in fs[:25]]})

    crit = [f for f in findings if f["severity"] == "CRITICAL"]
    high = [f for f in findings if f["severity"] == "HIGH"]
    if r.block_critical and crit:
        viol("block_critical", f"{len(crit)} critical finding(s) present.", crit)
    hf = [f for f in high if f["kind"] == "vulnerability" and f.get("fixed")]
    if r.block_high_with_fix and hf:
        viol("block_high_with_fix", f"{len(hf)} high-severity vulnerability(ies) have a known fixed version.", hf)
    if r.max_high is not None and len(high) > r.max_high:
        viol("max_high", f"{len(high)} high findings exceed the limit of {r.max_high}.", high)
    root = [f for f in findings if f.get("ref_id") in ROOT_RULES]
    if r.block_root and root:
        viol("block_root", "Container is configured to run as root.", root)
    banned = [f for f in findings if f.get("ref_id") in set(r.prohibited_rules)]
    if banned:
        viol("prohibited_rules", f"{len(banned)} finding(s) match prohibited rule IDs.", banned)
    if r.max_risk_score is not None and risk_score > r.max_risk_score:
        viol("max_risk_score", f"Risk score {risk_score} exceeds the limit of {r.max_risk_score}.", [])
    return {"outcome": "BLOCKED" if v else "APPROVED", "violations": v}


def record_hash(record: dict) -> str:
    return hashlib.sha256(json.dumps(record, sort_keys=True, default=str).encode()).hexdigest()
