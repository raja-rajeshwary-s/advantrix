import { useEffect, useState } from "react";
import { J, get, send, useAsync } from "../services/api";
import { Btn, Drawer, DemoTag, Err, Loading, Mono, SevBadge, fmt } from "./ui";

const VERIF: Record<string, [string, string]> = {
  none: ["No remediation recorded", "text-mute"], proposed: ["Proposed - not yet verified by a new scan", "text-amber"],
  verified: ["Verified: absent from a later scan", "text-lime"], not_resolved: ["Not resolved: still present in a later scan", "text-crit"],
};

export default function FindingInspector({ id, onClose }: { id: number | null; onClose: () => void }) {
  const q = useAsync(() => (id ? get(`/findings/${id}`) : Promise.resolve(null)), [id]);
  const [ex, setEx] = useState<J | null>(null);
  const [exLoading, setExLoading] = useState(false);
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { setEx(null); setNote(""); setMsg(null); setErr(null); }, [id]);
  const f = q.data;
  const explain = async () => { setExLoading(true); setErr(null); try { setEx(await send(`/findings/${id}/explain`, "POST")); } catch (e: any) { setErr(e.message); } setExLoading(false); };
  const record = async () => { setErr(null); try { const r = await send("/remediations", "POST", { finding_id: id, proposed_change: note }); setMsg(r.note); setNote(""); q.reload(); } catch (e: any) { setErr(e.message); } };
  return (
    <Drawer open={id !== null} onClose={onClose} title={f ? `${f.ref_id}` : "Finding"}>
      {q.loading && <Loading />}<Err msg={q.error} />
      {f && (<div className="space-y-5 text-[14px]">
        <div className="flex flex-wrap items-center gap-3"><SevBadge s={f.severity} />{f.scan.is_demo && <DemoTag />}<span className={`text-[12px] ${VERIF[f.verification][1]}`}>{VERIF[f.verification][0]}</span></div>
        <p className="font-display text-[18px] leading-snug">{f.title}</p>
        {f.description && <p className="text-mute">{f.description}</p>}
        <dl className="grid grid-cols-[110px_1fr] gap-y-1.5 border-y border-line py-3">
          {f.kind === "vulnerability" ? (<>
            <dt className="text-mute">Package</dt><dd><Mono>{f.pkg} {f.installed}</Mono></dd>
            <dt className="text-mute">Fixed in</dt><dd><Mono className={f.fixed ? "text-lime" : "text-amber"}>{f.fixed ?? "no fix reported by scanner"}</Mono></dd>
            <dt className="text-mute">Scanner CVSS</dt><dd><Mono>{f.cvss ?? "not provided"}{f.cvss_source ? ` (${f.cvss_source})` : ""}</Mono></dd></>) : (<>
            <dt className="text-mute">Rule</dt><dd><Mono>{f.ref_id}</Mono></dd>
            <dt className="text-mute">Location</dt><dd><Mono>{f.evidence?.target}{f.evidence?.line ? `:${f.evidence.line}` : ""}</Mono></dd>
            {f.evidence?.snippet && (<><dt className="text-mute">Evidence</dt><dd><Mono className="break-all">{f.evidence.snippet}</Mono></dd></>)}</>)}
          <dt className="text-mute">Image</dt><dd><Mono>{f.scan.image_ref}</Mono></dd>
          <dt className="text-mute">Scanned</dt><dd><Mono>{fmt(f.scan.scanned_at)}</Mono></dd>
          <dt className="text-mute">Evidence source</dt><dd><Mono>{f.evidence?.source}{f.evidence?.url ? ` - ${f.evidence.url}` : ""}</Mono></dd>
          <dt className="text-mute">Layer</dt><dd><Mono className="break-all">{f.layer_diff_id ? f.layer_diff_id.slice(0, 26) + "..." : f.layer_note ?? "n/a"}</Mono></dd>
        </dl>
        <div><h4 className="mb-1 font-display text-[16px]">Risk rationale</h4><p className="mb-1 text-mute">Contributes <Mono className="text-ivory">{f.risk_points}</Mono> points to the image risk score:</p>
          <ul className="list-disc pl-5 text-mute">{f.risk_rationale.map((r: string) => <li key={r}>{r}</li>)}</ul></div>
        {f.resolution && <div><h4 className="mb-1 font-display text-[16px]">Scanner-provided resolution</h4><p className="text-mute">{f.resolution}</p></div>}
        <div className="border border-line p-3">
          <div className="mb-2 flex items-center justify-between"><h4 className="font-display text-[16px]">Remediation assistant</h4><Btn onClick={explain} disabled={exLoading}>{exLoading ? "Working..." : "Explain and suggest"}</Btn></div>
          {ex && (<div className="space-y-2">
            <p className="font-mono text-[11px] text-mute">mode: {ex.mode} / finding #{ex.finding_id}</p>
            {ex.narrative && <p>{ex.narrative}</p>}
            <div><b className="text-lime">Verified facts (from scan data)</b><ul className="list-disc pl-5 text-mute">{ex.facts.map((x: string) => <li key={x}>{x}</li>)}</ul></div>
            <div><b className="text-amber">Suggestions (not verified)</b><ul className="list-disc pl-5 text-mute">{ex.suggestions.map((x: string) => <li key={x}>{x}</li>)}</ul></div>
            <div><b>Uncertainty</b><ul className="list-disc pl-5 text-mute">{ex.uncertainty.map((x: string) => <li key={x}>{x}</li>)}</ul></div>
            <p className="text-[12px] text-mute">{ex.note}</p></div>)}
        </div>
        <div><h4 className="mb-1 font-display text-[16px]">Record a remediation</h4>
          <textarea aria-label="Proposed remediation" value={note} onChange={(e) => setNote(e.target.value)} rows={3} maxLength={2000} placeholder="What will you change? e.g. Bump base image to alpine:3.19 and rebuild"
            className="w-full border border-line bg-graphite p-2 text-[13px]" />
          <div className="mt-2 flex items-center gap-3"><Btn kind="primary" onClick={record} disabled={note.trim().length < 3}>Record proposal</Btn>
            <span className="text-[12px] text-mute">Marked verified only after a new scan is compared.</span></div>
          {msg && <p className="mt-2 text-[12px] text-lime">{msg}</p>}
          {f.remediations.length > 0 && <ul className="mt-3 space-y-1 border-t border-line pt-2 text-[13px]">{f.remediations.map((r: J) => <li key={r.id}><Mono className="text-mute">{fmt(r.created_at)}</Mono> - {r.proposed_change} <Mono className="text-amber">[{r.status}]</Mono></li>)}</ul>}
        </div>
        <Err msg={err} />
      </div>)}
    </Drawer>
  );
}
