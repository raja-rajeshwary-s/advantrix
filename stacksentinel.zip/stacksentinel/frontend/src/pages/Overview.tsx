import { Link, useNavigate } from "react-router-dom";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { get, useAsync } from "../services/api";
import { Card, DemoTag, Decision, Err, Loading, Mono, PageHead, SEV_COLOR, SEVS, fmt } from "../components/ui";
import { useApp } from "../components/Shell";

const STAGES = [["Build", "build"], ["Scan", "scan"], ["Analyse", "analyse"]] as const;

export default function Overview() {
  const q = useAsync(() => get("/overview"), []);
  const { setScanId } = useApp();
  const nav = useNavigate();
  const o = q.data;
  if (q.loading) return <Loading />;
  if (!o) return <Err msg={q.error} />;
  const sev = SEVS.map((s) => ({ s, n: o.severity[s] }));
  const open = (id: number, to = "/findings") => { setScanId(id); nav(to); };
  return (<>
    <PageHead title="Security overview" sub="The latest scan of every image, judged against the active policy. Counts include seeded demo records, which are labelled." />
    {o.images.demo > 0 && <div className="mb-5 flex items-center gap-3 border border-amber/60 bg-amber/10 px-4 py-2 text-[13px]"><DemoTag /><span>{o.images.demo} of {o.images.total} images are seeded synthetic demo data. {o.images.live === 0 ? "No live scans have been imported yet - use Inspect to add one." : `${o.images.live} come from real imported scans.`}</span></div>}
    <Card title="Trust pipeline" className="mb-5">
      <ol className="grid grid-cols-2 gap-px bg-line text-center md:grid-cols-5">
        {[...STAGES.map(([l, k]) => [l, o.pipeline[k], "text-ivory"]), ["Policy gate", o.images.passing + o.images.failing, "text-ivory"]].map(([l, n, c]: any) => (
          <li key={l} className="bg-graphite py-3"><div className="text-[12px] text-mute">{l}</div><div className={`font-display text-[24px] ${c}`}>{n}</div></li>))}
        <li className="col-span-2 flex items-stretch bg-graphite md:col-span-1"><div className="flex-1 border-r border-line py-3"><div className="text-[12px] text-lime">Approved</div><div className="font-display text-[24px] text-lime">{o.pipeline.approved}</div></div>
          <div className="flex-1 py-3"><div className="text-[12px] text-crit">Blocked</div><div className="font-display text-[24px] text-crit">{o.pipeline.blocked}</div></div></li>
      </ol>
    </Card>
    <div className="mb-5 grid gap-5 md:grid-cols-[1.1fr_1fr]">
      <Card title="Severity distribution (all latest scans)">
        <div className="h-[200px]"><ResponsiveContainer><BarChart data={sev} layout="vertical" margin={{ left: 10 }}>
          <XAxis type="number" stroke="#9a9887" fontSize={11} allowDecimals={false} /><YAxis type="category" dataKey="s" stroke="#9a9887" fontSize={11} width={74} />
          <Tooltip cursor={{ fill: "#ffffff10" }} contentStyle={{ background: "#111210", border: "1px solid #33372f" }} />
          <Bar dataKey="n" name="findings">{sev.map((d) => <Cell key={d.s} fill={SEV_COLOR[d.s]} />)}</Bar></BarChart></ResponsiveContainer></div>
      </Card>
      <Card title="Most common vulnerable packages">
        {o.top_packages.length === 0 ? <p className="text-mute">No package findings yet.</p> : (
          <div className="h-[200px]"><ResponsiveContainer><BarChart data={o.top_packages} layout="vertical" margin={{ left: 10 }}>
            <XAxis type="number" stroke="#9a9887" fontSize={11} allowDecimals={false} /><YAxis type="category" dataKey="pkg" stroke="#9a9887" fontSize={11} width={74} />
            <Tooltip cursor={{ fill: "#ffffff10" }} contentStyle={{ background: "#111210", border: "1px solid #33372f" }} /><Bar dataKey="count" name="findings" fill="#b8f03c" /></BarChart></ResponsiveContainer></div>)}
      </Card>
    </div>
    <Card title="Image inventory" className="mb-5" aside={<Mono className="text-mute">{o.images.passing} pass / {o.images.failing} fail</Mono>}>
      <div className="overflow-x-auto"><table className="w-full text-left text-[13px]"><thead className="text-mute"><tr className="border-b border-line"><th className="py-1.5">Image</th><th>Gate</th><th>Risk</th><th>Crit</th><th>High</th><th>Findings</th><th /></tr></thead>
        <tbody>{o.inventory.map((r: any) => (<tr key={r.scan.id} className="border-b border-line/60">
          <td className="py-2"><Mono>{r.scan.image_ref}</Mono> {r.scan.is_demo && <DemoTag />}</td><td><Decision d={r.decision} /></td>
          <td><Mono>{r.risk_score}</Mono> <span className="text-mute">{r.risk_class}</span></td><td><Mono className={r.critical ? "text-crit" : ""}>{r.critical}</Mono></td><td><Mono>{r.high}</Mono></td><td><Mono>{r.findings}</Mono></td>
          <td className="space-x-3 text-right"><button className="text-lime hover:underline" onClick={() => open(r.scan.id)}>Findings</button><button className="text-lime hover:underline" onClick={() => open(r.scan.id, "/layers")}>Layers</button></td></tr>))}</tbody></table></div>
    </Card>
    <div className="grid gap-5 md:grid-cols-2">
      <Card title="Images requiring remediation">
        {o.needs_remediation.length === 0 ? <p className="text-mute">Nothing is blocked right now.</p> : <ul className="space-y-2">{o.needs_remediation.map((r: any) => (
          <li key={r.scan.id} className="flex items-center justify-between"><Mono>{r.scan.image_ref}</Mono><Link className="text-[13px] text-lime hover:underline" to="/verify" onClick={() => setScanId(r.scan.id)}>Start fix-to-verify</Link></li>))}</ul>}
      </Card>
      <Card title="Container trust timeline">
        <ol className="relative ml-2 border-l border-line pl-4">{o.recent.map((s: any) => (<li key={s.id} className="relative pb-3"><span aria-hidden className="absolute -left-[21px] top-1.5 h-2.5 w-2.5 bg-lime" />
          <Mono>{s.image_ref}</Mono> {s.is_demo && <DemoTag />}<div className="text-[12px] text-mute">#{s.id} via {s.source} - {fmt(s.scanned_at)}</div></li>))}</ol>
      </Card>
    </div>
  </>);
}
