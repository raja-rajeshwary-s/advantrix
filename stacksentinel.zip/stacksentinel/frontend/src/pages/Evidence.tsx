import { useState } from "react";
import { J, get, send, upload, useAsync } from "../services/api";
import { Btn, Card, DemoTag, Err, Mono, PageHead, fmt, short } from "../components/ui";
import { useApp } from "../components/Shell";

export default function Evidence() {
  const { scanId, scan, scans } = useApp();
  const list = useAsync(() => (scanId ? get(`/scans/${scanId}/reports`) : Promise.resolve([])), [scanId]);
  const [cmp, setCmp] = useState<number | "">("");
  const [prev, setPrev] = useState<J | null>(null);
  const [vr, setVr] = useState<J | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const make = async (kind: string) => { setErr(null); try { const r = await send(`/scans/${scanId}/reports`, "POST", { kind, compare_with_scan_id: kind === "report" && cmp ? cmp : null }); setPrev(r); list.reload(); } catch (e: any) { setErr(e.message); } };
  const check = async (file?: File) => { if (!file) return; setErr(null); const f = new FormData(); f.append("file", file); try { setVr(await upload("/reports/verify", f)); } catch (e: any) { setErr(e.message); } };
  return (<>
    <PageHead title="Evidence centre" sub="Generate a full evidence report or a compact decision receipt. Each export is hashed with SHA-256 so later tampering is detectable." right={scan?.is_demo ? <DemoTag /> : undefined} />
    <Err msg={err} />
    <div className="grid gap-5 md:grid-cols-2">
      <Card title={`Generate for #${scanId} ${scan?.image_ref ?? ""}`}><div className="space-y-3 text-[13px]">
        <label className="block text-mute">Include before/after comparison with (optional)<select value={cmp} onChange={(e) => setCmp(e.target.value === "" ? "" : Number(e.target.value))} className="mt-1 block w-full border border-line bg-ink p-1.5 text-ivory"><option value="">None</option>{scans.filter((s) => s.id !== scanId).map((s) => <option key={s.id} value={s.id}>#{s.id} {s.image_ref}</option>)}</select></label>
        <div className="flex gap-3"><Btn kind="primary" onClick={() => make("report")} disabled={!scanId}>Evidence report (.md)</Btn><Btn onClick={() => make("receipt")} disabled={!scanId}>Decision receipt (.json)</Btn></div></div></Card>
      <Card title="Verify an exported file"><div className="space-y-3 text-[13px]"><label className="block text-mute">Choose a downloaded report or receipt<input type="file" onChange={(e) => check(e.target.files?.[0])} className="mt-1 block text-[12px]" /></label>
        {vr && <div className={`border p-3 ${vr.valid ? "border-lime/60" : "border-crit/60"}`}><b className={vr.valid ? "text-lime" : "text-crit"}>{vr.valid ? "Integrity verified" : "No match - file altered or not generated here"}</b>
          <div className="mt-1 break-all font-mono text-[11px] text-mute">{vr.sha256}</div>{vr.valid && <div className="mt-1 text-[12px]">{vr.kind} for scan #{vr.scan_id}, generated {fmt(vr.generated_at)}</div>}<p className="mt-2 text-[12px] text-mute">{vr.note}</p></div>}</div></Card>
    </div>
    <Card title="Exports for this scan" className="mt-5">{!list.data?.length ? <p className="text-mute">Nothing generated yet.</p> : (
      <table className="w-full text-left text-[13px]"><thead className="text-mute"><tr className="border-b border-line"><th className="py-1.5">File</th><th>Created</th><th>SHA-256</th><th /></tr></thead>
        <tbody>{list.data.map((r: any) => <tr key={r.id} className="border-b border-line/60"><td className="py-1.5"><Mono>{r.filename}</Mono> {r.is_demo && <DemoTag />}</td><td><Mono>{fmt(r.created_at)}</Mono></td><td><Mono>{short(r.sha256, 16)}...</Mono></td>
          <td className="text-right"><a className="text-lime hover:underline" href={`/api/reports/${r.id}/download`} download>Download</a></td></tr>)}</tbody></table>)}</Card>
    {prev && <Card title="Latest export preview" className="mt-5"><pre className="max-h-96 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-mute">{prev.preview}</pre></Card>}
  </>);
}
