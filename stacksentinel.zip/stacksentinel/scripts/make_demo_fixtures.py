"""Generate SYNTHETIC Trivy-format demo reports into data/demo. Nothing here is a real scan.
Vulnerability IDs use the DEMO-VULN-#### namespace on purpose so no real CVE is misrepresented."""
import hashlib, json, pathlib

OUT = pathlib.Path(__file__).resolve().parents[1] / "data" / "demo"
OUT.mkdir(parents=True, exist_ok=True)


def diff(name): return "sha256:" + hashlib.sha256(name.encode()).hexdigest()


def V(i, pkg, ver, fix, sev, cvss, layer, title):
    return {"VulnerabilityID": f"DEMO-VULN-{i:04d}", "PkgName": pkg, "InstalledVersion": ver, "FixedVersion": fix, "Severity": sev,
            "Title": title, "Description": f"SYNTHETIC DEMO RECORD. {title} in package {pkg}. Not a real vulnerability.",
            "PrimaryURL": "https://example.invalid/demo-vuln/" + str(i), "CVSS": {"nvd": {"V3Score": cvss}} if cvss else None,
            "Layer": {"DiffID": layer, "Digest": "sha256:" + hashlib.sha256(layer.encode()).hexdigest()}}


def image(name, tag, created, hist, vulns, os_ver="3.18"):
    layers = [diff(f"{name}:{tag}:{h}") for h in hist]
    vs = [V(*(v[:6] + (layers[v[6]],) + v[7:])) for v in vulns]
    rep = {"SchemaVersion": 2, "ArtifactName": f"{name}:{tag}", "ArtifactType": "container_image", "CreatedAt": created,
           "TrivyVersion": "demo-fixture (synthetic)",
           "Metadata": {"OS": {"Family": "alpine", "Name": os_ver}, "RepoDigests": [f"{name}@sha256:" + hashlib.sha256((name + tag).encode()).hexdigest()],
                        "DiffIDs": layers, "ImageConfig": {"history": [{"created_by": h} for h in hist]}},
           "Results": [{"Target": f"{name}:{tag} (alpine {os_ver})", "Class": "os-pkgs", "Type": "alpine", "Vulnerabilities": vs}]}
    (OUT / f"{name.split('/')[-1]}-{tag}.trivy.json").write_text(json.dumps(rep, indent=2))


H = ["ADD alpine-minirootfs (base image)", "RUN apk add --no-cache openssl zlib libxml2", "COPY app /srv/app", "RUN pip install -r requirements.txt"]
# (id, pkg, ver, fixed, sev, cvss, layer_idx, title)
image("demo/clean-api", "1.4.2", "2026-10-12T09:00:00Z", H[:3],
      [(1001, "busybox", "1.36.1-r2", None, "LOW", 3.1, 0, "Minor information disclosure")])
image("demo/web-frontend", "2.1.0", "2026-10-13T11:30:00Z", H,
      [(2001, "openssl", "3.1.1-r0", "3.1.4-r0", "HIGH", 7.5, 1, "Denial of service in TLS handshake"),
       (2002, "libxml2", "2.11.4-r0", "2.11.6-r0", "HIGH", 7.8, 1, "Memory corruption when parsing crafted XML"),
       (2003, "zlib", "1.2.13-r0", "1.2.13-r1", "HIGH", 7.0, 1, "Heap overflow in decompression"),
       (2004, "pip", "23.0.1", "23.3", "MEDIUM", 5.5, 3, "Unsafe URL handling"),
       (2005, "busybox", "1.36.1-r2", None, "MEDIUM", 5.0, 0, "Archive extraction path issue"),
       (2006, "musl", "1.2.4-r0", None, "LOW", 3.7, 0, "Locale parsing edge case")])
image("demo/payments-svc", "0.9.0", "2026-10-14T14:10:00Z", H,
      [(3001, "openssl", "3.1.1-r0", "3.1.4-r0", "CRITICAL", 9.8, 1, "Remote code execution in certificate parsing"),
       (3002, "libxml2", "2.11.4-r0", "2.11.6-r0", "HIGH", 7.8, 1, "Memory corruption when parsing crafted XML"),
       (3003, "zlib", "1.2.13-r0", "1.2.13-r1", "HIGH", 7.0, 1, "Heap overflow in decompression"),
       (3004, "pip", "23.0.1", "23.3", "MEDIUM", 5.5, 3, "Unsafe URL handling"),
       (3005, "busybox", "1.36.1-r2", None, "MEDIUM", 5.0, 0, "Archive extraction path issue")])
image("demo/legacy-batch", "3.0.0", "2026-10-15T08:45:00Z", ["ADD debian-rootfs (base image)", "RUN apt-get update && apt-get install -y curl", "COPY batch /opt/batch"],
      [(4001, "curl", "7.88.1-r0", None, "HIGH", 7.4, 1, "Credential leak on redirect (no fix released in this fixture)"),
       (4002, "libc", "2.36-r0", None, "HIGH", 7.1, 0, "Race condition in resolver"),
       (4003, "tar", "1.34-r0", "1.35-r0", "MEDIUM", 5.3, 0, "Directory traversal on extract")], "12")
# Fixed build: critical + highs resolved, one medium still open, one NEW low introduced by an added package
image("demo/payments-svc", "0.9.1", "2026-10-16T10:20:00Z", H + ["RUN apk add --no-cache jq"],
      [(3004, "pip", "23.0.1", "23.3", "MEDIUM", 5.5, 3, "Unsafe URL handling"),
       (3005, "busybox", "1.36.1-r2", None, "MEDIUM", 5.0, 0, "Archive extraction path issue"),
       (3006, "jq", "1.7-r0", "1.7.1-r0", "LOW", 3.3, 4, "Stack exhaustion on deeply nested input")])

(OUT / "legacy-batch.Dockerfile").write_text("""FROM debian:latest
ENV DB_PASSWORD=changeme123
ADD https://example.invalid/tool.tar.gz /opt/
RUN apt-get update && apt-get install -y curl
RUN curl -sSL https://example.invalid/install.sh | sh
RUN chmod -R 777 /opt/batch
EXPOSE 22
COPY batch /opt/batch
CMD ["/opt/batch/run.sh"]
""")
print("fixtures written to", OUT)
